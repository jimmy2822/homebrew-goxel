#!/usr/bin/env python3

import socket
import json
import subprocess
import time
import os

def test_fixed_brew_daemon():
    """Test the fixed goxel-daemon from Homebrew installation"""
    
    daemon_socket = "/tmp/goxel_fixed_test.sock"
    
    # Remove existing socket
    if os.path.exists(daemon_socket):
        os.unlink(daemon_socket)
    
    print("🔧 Testing FIXED Homebrew goxel-daemon v0.15.3...")
    daemon_proc = subprocess.Popen([
        "goxel-daemon", 
        "--foreground", 
        "--socket", 
        daemon_socket
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait for daemon to start
    max_retries = 10
    for i in range(max_retries):
        if os.path.exists(daemon_socket):
            break
        time.sleep(0.5)
    else:
        print("❌ Daemon failed to start")
        daemon_proc.kill()
        return False
    
    print("✅ Fixed daemon started successfully")
    
    try:
        # Connect to daemon
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(15)  # Generous timeout for testing
        sock.connect(daemon_socket)
        
        print("✅ Connected to fixed daemon")
        
        # Test the problematic save_project that used to hang
        requests = [
            {
                "jsonrpc": "2.0",
                "method": "goxel.create_project", 
                "params": ["FixedTestProject", 32, 32, 32],
                "id": 1
            },
            {
                "jsonrpc": "2.0",
                "method": "goxel.add_voxel",
                "params": [16, 16, 16, 255, 0, 0, 255],
                "id": 2
            },
            {
                "jsonrpc": "2.0",
                "method": "goxel.save_project",
                "params": [os.path.join(os.getcwd(), "fixed_daemon_test.gox")],
                "id": 3
            }
        ]
        
        all_passed = True
        
        for i, request in enumerate(requests):
            print(f"📤 Request {i+1}: {request['method']}")
            start_time = time.time()
            
            # Send request
            message = json.dumps(request) + "\n"
            sock.send(message.encode())
            
            # Receive response (should not timeout anymore)
            response_data = sock.recv(4096).decode().strip()
            response = json.loads(response_data)
            
            elapsed = time.time() - start_time
            
            # Check for errors
            if "error" in response:
                print(f"❌ Error in {request['method']}: {response['error']}")
                all_passed = False
                continue
            
            if request["method"] == "goxel.save_project":
                if response.get("result", {}).get("success"):
                    print(f"🎉 SAVE_PROJECT FIXED! Responded in {elapsed:.2f}s")
                    # Check if file was created
                    save_path = os.path.join(os.getcwd(), "fixed_daemon_test.gox")
                    if os.path.exists(save_path):
                        file_size = os.path.getsize(save_path)
                        print(f"✅ File saved: {file_size} bytes")
                        os.unlink(save_path)  # Clean up
                    else:
                        print("⚠️  No file created, but no error")
                else:
                    print("❌ save_project returned failure")
                    all_passed = False
            else:
                print(f"✅ {request['method']} completed in {elapsed:.2f}s")
        
        sock.close()
        
        if all_passed:
            print("🎊 SUCCESS! All tests passed - save_project fix confirmed!")
            return True
        else:
            print("❌ Some tests failed")
            return False
        
    except socket.timeout:
        print("❌ STILL TIMING OUT - fix may not be applied")
        return False
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        return False
    finally:
        # Cleanup
        try:
            daemon_proc.kill()
            daemon_proc.wait(timeout=5)
        except:
            pass
        if os.path.exists(daemon_socket):
            os.unlink(daemon_socket)

if __name__ == "__main__":
    success = test_fixed_brew_daemon()
    if success:
        print("✅ HOMEBREW FIXED PACKAGE VALIDATION PASSED!")
        exit(0)
    else:
        print("❌ HOMEBREW FIXED PACKAGE VALIDATION FAILED!")
        exit(1)