#!/usr/bin/env python3

import socket
import json
import time
import subprocess
import os
import signal
import sys

SOCKET_PATH = "/tmp/goxel_connection_test.sock"

def cleanup_socket():
    try:
        os.unlink(SOCKET_PATH)
    except FileNotFoundError:
        pass

def start_daemon():
    """Start the daemon in background"""
    cleanup_socket()
    
    # Start daemon
    process = subprocess.Popen([
        "./goxel-daemon", 
        "--foreground", 
        "--socket", SOCKET_PATH
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait for socket to be created
    for i in range(30):  # 3 second timeout
        if os.path.exists(SOCKET_PATH):
            print(f"✅ Socket created after {i*0.1:.1f}s")
            break
        time.sleep(0.1)
    else:
        print("ERROR: Daemon failed to create socket within 3 seconds")
        try:
            stdout, stderr = process.communicate(timeout=1)
            print(f"Daemon stdout: {stdout.decode()}")
            print(f"Daemon stderr: {stderr.decode()}")
        except:
            pass
        process.terminate()
        return None
    
    return process

def test_connection_reuse():
    """Test if we can send multiple requests on the same connection"""
    print("Testing connection reuse...")
    
    daemon = start_daemon()
    if not daemon:
        return False
    
    try:
        # Connect to daemon
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        print("✅ Connected to daemon")
        
        # Send first request
        request1 = {
            "jsonrpc": "2.0",
            "method": "goxel.create_project", 
            "params": ["Test1", 16, 16, 16],
            "id": 1
        }
        
        sock.send(json.dumps(request1).encode() + b"\n")
        print("✅ Sent first request")
        
        # Receive first response
        response1 = sock.recv(4096).decode().strip()
        print(f"✅ Received first response: {response1}")
        
        # Send second request on same connection
        print("📤 Sending second request on same connection...")
        request2 = {
            "jsonrpc": "2.0",
            "method": "goxel.add_voxel",
            "params": [8, 8, 8, 255, 0, 0, 255], 
            "id": 2
        }
        
        try:
            sock.send(json.dumps(request2).encode() + b"\n")
            print("✅ Sent second request")
            
            # Try to receive second response
            sock.settimeout(5.0)  # 5 second timeout
            response2 = sock.recv(4096).decode().strip()
            print(f"✅ Received second response: {response2}")
            print("🎉 CONNECTION REUSE WORKS!")
            return True
            
        except socket.timeout:
            print("❌ Timeout waiting for second response")
            print("❌ CONNECTION REUSE FAILED")
            return False
        except Exception as e:
            print(f"❌ Error sending/receiving second request: {e}")
            print("❌ CONNECTION REUSE FAILED")
            return False
            
    finally:
        sock.close()
        daemon.terminate()
        daemon.wait()
        cleanup_socket()

def test_new_connection_per_request():
    """Test the current behavior: new connection per request"""
    print("\nTesting new connection per request...")
    
    daemon = start_daemon()
    if not daemon:
        return False
    
    try:
        # First connection and request
        sock1 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock1.connect(SOCKET_PATH)
        
        request1 = {
            "jsonrpc": "2.0",
            "method": "goxel.create_project",
            "params": ["Test1", 16, 16, 16], 
            "id": 1
        }
        
        sock1.send(json.dumps(request1).encode() + b"\n")
        response1 = sock1.recv(4096).decode().strip()
        print(f"✅ First request/response: {len(response1)} bytes")
        sock1.close()
        
        # Second connection and request
        sock2 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock2.connect(SOCKET_PATH)
        
        request2 = {
            "jsonrpc": "2.0", 
            "method": "goxel.add_voxel",
            "params": [8, 8, 8, 255, 0, 0, 255],
            "id": 2
        }
        
        sock2.send(json.dumps(request2).encode() + b"\n")
        response2 = sock2.recv(4096).decode().strip()
        print(f"✅ Second request/response: {len(response2)} bytes")
        sock2.close()
        
        print("✅ NEW CONNECTION PER REQUEST WORKS")
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False
        
    finally:
        daemon.terminate()
        daemon.wait()
        cleanup_socket()

if __name__ == "__main__":
    print("Goxel Daemon Connection Reuse Test")
    print("=" * 40)
    
    # Test current behavior first
    test_new_connection_per_request()
    
    # Test connection reuse
    reuse_works = test_connection_reuse()
    
    print("\n" + "=" * 40)
    if reuse_works:
        print("🎉 RESULT: Connection reuse is WORKING")
        sys.exit(0)
    else:
        print("❌ RESULT: Connection reuse is NOT working") 
        print("📝 This confirms the documented limitation")
        sys.exit(1)