#!/usr/bin/env python3

import socket
import json
import time
import os

SOCKET_PATH = "/tmp/goxel_test_osmesa.sock"
OUTPUT_PNG = "/tmp/test_osmesa_render.png"

def send_request(sock, method, params):
    """Send a JSON-RPC request and return the response"""
    request = {
        "jsonrpc": "2.0",
        "method": method,
        "params": params,
        "id": 1
    }
    
    # Send request
    sock.send(json.dumps(request).encode() + b"\n")
    
    # Read response
    response = sock.recv(4096)
    return json.loads(response)

def test_render():
    """Test rendering with OSMesa"""
    
    # Clean up any existing output
    if os.path.exists(OUTPUT_PNG):
        os.remove(OUTPUT_PNG)
    
    print("Testing OSMesa rendering...")
    
    # Create project
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(SOCKET_PATH)
    resp = send_request(sock, "goxel.create_project", ["TestRender", 32, 32, 32])
    print(f"Create project: {resp}")
    sock.close()
    
    # Add some voxels in a pattern
    colors = [
        (16, 16, 16, 255, 0, 0, 255),    # Red
        (17, 16, 16, 0, 255, 0, 255),    # Green
        (15, 16, 16, 0, 0, 255, 255),    # Blue
        (16, 17, 16, 255, 255, 0, 255),  # Yellow
        (16, 15, 16, 255, 0, 255, 255),  # Magenta
        (16, 16, 17, 0, 255, 255, 255),  # Cyan
    ]
    
    for voxel in colors:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        resp = send_request(sock, "goxel.add_voxel", list(voxel))
        print(f"Add voxel {voxel[:3]}: {resp}")
        sock.close()
    
    # Render the scene
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(SOCKET_PATH)
    resp = send_request(sock, "goxel.render_scene", [OUTPUT_PNG, 800, 600])
    print(f"Render scene: {resp}")
    sock.close()
    
    # Check if output was created
    if os.path.exists(OUTPUT_PNG):
        size = os.path.getsize(OUTPUT_PNG)
        print(f"✅ Render successful! Output: {OUTPUT_PNG} ({size} bytes)")
        print(f"Opening image...")
        os.system(f"open {OUTPUT_PNG}")
    else:
        print("❌ Render failed - no output file created")

if __name__ == "__main__":
    test_render()