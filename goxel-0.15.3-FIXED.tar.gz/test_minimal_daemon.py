#!/usr/bin/env python3
"""Minimal test to check daemon basic functionality"""

import socket
import json
import subprocess
import time
import os
import sys

# Kill any existing daemon
os.system("pkill -f goxel-daemon 2>/dev/null")
time.sleep(0.5)

# Start daemon
print("Starting daemon...")
daemon = subprocess.Popen([
    "./goxel-daemon",
    "--foreground", 
    "--socket", "/tmp/minimal_test.sock",
    "--verbose"
], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# Wait for daemon to start
time.sleep(2.0)

# Check if daemon is still running
if daemon.poll() is not None:
    print("ERROR: Daemon crashed on startup")
    stdout, stderr = daemon.communicate()
    print("STDOUT:", stdout.decode())
    print("STDERR:", stderr.decode())
    sys.exit(1)

print("Daemon started successfully")

# Test simple echo request
try:
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect("/tmp/minimal_test.sock")
    sock.settimeout(5.0)
    
    # Send echo request
    req = {"jsonrpc": "2.0", "method": "echo", "params": ["Hello"], "id": 1}
    print(f"\nSending: {json.dumps(req)}")
    sock.send(json.dumps(req).encode() + b"\n")
    
    # Try to receive response
    response = b""
    start_time = time.time()
    while time.time() - start_time < 3.0:
        try:
            chunk = sock.recv(4096)
            if chunk:
                response += chunk
                if b"\n" in response:
                    break
        except socket.timeout:
            break
    
    if response:
        print(f"Received: {response.decode().strip()}")
    else:
        print("No response received")
    
    sock.close()
except Exception as e:
    print(f"Error: {e}")

# Kill daemon
daemon.terminate()
daemon.wait()

print("\nDone.")