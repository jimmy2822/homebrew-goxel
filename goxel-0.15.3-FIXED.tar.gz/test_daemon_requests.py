#!/usr/bin/env python3
"""Test daemon's ability to handle multiple requests"""

import socket
import json
import time

def test_daemon_requests():
    # Connect to daemon
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    
    try:
        sock.connect("/tmp/goxel_integration_test.sock")
        print("✓ Connected to daemon")
    except Exception as e:
        print(f"✗ Failed to connect: {e}")
        return False
    
    # First request
    request1 = {
        "jsonrpc": "2.0",
        "method": "goxel.create_project",
        "params": ["Test1", 16, 16, 16],
        "id": 1
    }
    
    print("\nSending first request...")
    sock.send(json.dumps(request1).encode() + b"\n")
    
    # Wait for response
    response1 = sock.recv(4096).decode()
    print(f"First response: {response1}")
    
    if "error" in response1:
        print("✗ First request failed")
        return False
    else:
        print("✓ First request succeeded")
    
    # Second request on same connection
    request2 = {
        "jsonrpc": "2.0",
        "method": "goxel.create_project",
        "params": ["Test2", 32, 32, 32],
        "id": 2
    }
    
    print("\nSending second request...")
    sock.send(json.dumps(request2).encode() + b"\n")
    
    # Wait for response with timeout
    sock.settimeout(2.0)
    try:
        response2 = sock.recv(4096).decode()
        print(f"Second response: {response2}")
        
        if "error" in response2:
            print("✗ Second request failed")
            return False
        else:
            print("✓ Second request succeeded!")
            return True
    except socket.timeout:
        print("✗ Second request timed out (daemon hung)")
        return False
    finally:
        sock.close()

if __name__ == "__main__":
    # Start daemon first
    import subprocess
    import os
    
    # Kill any existing daemon
    os.system("pkill -f goxel-daemon 2>/dev/null")
    time.sleep(0.5)
    
    # Start daemon
    print("Starting daemon...")
    daemon = subprocess.Popen([
        "./goxel-daemon",
        "--foreground",
        "--socket", "/tmp/goxel_integration_test.sock",
        "--verbose"
    ], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    
    # Wait for daemon to start
    time.sleep(1.0)
    
    # Run test
    success = test_daemon_requests()
    
    # Kill daemon
    daemon.terminate()
    daemon.wait()
    
    if success:
        print("\n✅ DAEMON CAN HANDLE MULTIPLE REQUESTS!")
    else:
        print("\n❌ DAEMON STILL HANGS ON SECOND REQUEST")
    
    exit(0 if success else 1)