#!/usr/bin/env python3
"""Simple test for daemon second request handling"""

import socket
import json
import subprocess
import time
import os

# Kill any existing daemon
os.system("pkill -f goxel-daemon 2>/dev/null")
time.sleep(0.5)

# Start daemon
print("Starting daemon...")
daemon = subprocess.Popen([
    "./goxel-daemon",
    "--foreground", 
    "--socket", "/tmp/test_simple.sock"
], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

# Wait for daemon to start
time.sleep(1.5)

# Test 1: Two requests on same connection
print("\n=== Test 1: Two requests on same connection ===")
try:
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect("/tmp/test_simple.sock")
    sock.settimeout(2.0)
    
    # First request
    req1 = {"jsonrpc": "2.0", "method": "goxel.create_project", "params": ["Test1", 16, 16, 16], "id": 1}
    sock.send(json.dumps(req1).encode() + b"\n")
    resp1 = sock.recv(4096).decode()
    print(f"Request 1 response: {resp1.strip()}")
    
    # Second request
    req2 = {"jsonrpc": "2.0", "method": "goxel.create_project", "params": ["Test2", 32, 32, 32], "id": 2}
    sock.send(json.dumps(req2).encode() + b"\n")
    resp2 = sock.recv(4096).decode()
    print(f"Request 2 response: {resp2.strip()}")
    print("✓ Test 1 PASSED: Two requests on same connection")
    
    sock.close()
except Exception as e:
    print(f"✗ Test 1 FAILED: {e}")

# Test 2: Two requests on different connections
print("\n=== Test 2: Two requests on different connections ===")
try:
    # First connection
    sock1 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock1.connect("/tmp/test_simple.sock")
    sock1.settimeout(2.0)
    
    req1 = {"jsonrpc": "2.0", "method": "goxel.create_project", "params": ["Test3", 16, 16, 16], "id": 3}
    sock1.send(json.dumps(req1).encode() + b"\n")
    resp1 = sock1.recv(4096).decode()
    print(f"Connection 1 response: {resp1.strip()}")
    sock1.close()
    
    # Second connection
    sock2 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock2.connect("/tmp/test_simple.sock")
    sock2.settimeout(2.0)
    
    req2 = {"jsonrpc": "2.0", "method": "goxel.create_project", "params": ["Test4", 32, 32, 32], "id": 4}
    sock2.send(json.dumps(req2).encode() + b"\n")
    resp2 = sock2.recv(4096).decode()
    print(f"Connection 2 response: {resp2.strip()}")
    sock2.close()
    
    print("✓ Test 2 PASSED: Two requests on different connections")
except Exception as e:
    print(f"✗ Test 2 FAILED: {e}")

# Kill daemon
daemon.terminate()
daemon.wait()

print("\nDone.")