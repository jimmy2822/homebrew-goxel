#!/usr/bin/env python3

import socket
import json
import subprocess
import time
import os
import signal

def test_immediate_daemon():
    """Test the daemon immediately with a simple request"""
    
    daemon_socket = "/tmp/goxel_immediate_test.sock"
    
    # Remove existing socket
    if os.path.exists(daemon_socket):
        os.unlink(daemon_socket)
    
    # Start the daemon in background
    print("🧪 Starting local daemon...")
    daemon_proc = subprocess.Popen([
        "./goxel-daemon", 
        "--foreground", 
        "--socket", 
        daemon_socket
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait for daemon to start
    max_retries = 10
    for i in range(max_retries):
        if os.path.exists(daemon_socket):
            break
        time.sleep(0.5)
    else:
        print("❌ Daemon failed to start")
        daemon_proc.kill()
        return False
    
    print("✅ Daemon started")
    
    try:
        # Connect to daemon
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(5)  # Short timeout for quick test
        sock.connect(daemon_socket)
        
        print("✅ Connected to daemon")
        
        # Test simple create_project request
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.create_project",
            "params": ["TestProject", 16, 16, 16],
            "id": 1
        }
        
        print("📤 Sending create_project request")
        start_time = time.time()
        
        # Send request
        message = json.dumps(request) + "\n"
        sock.send(message.encode())
        
        # Receive response 
        response_data = sock.recv(4096).decode().strip()
        response = json.loads(response_data)
        
        elapsed = time.time() - start_time
        
        print(f"📥 Response (took {elapsed:.2f}s): {response}")
        
        # Check for errors
        if "error" in response:
            print(f"❌ Error: {response['error']}")
            return False
        else:
            print("✅ create_project succeeded!")
            return True
            
    except socket.timeout:
        print("❌ Request timed out")
        return False
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        return False
    finally:
        # Cleanup
        try:
            sock.close()
        except:
            pass
        try:
            daemon_proc.terminate()
            daemon_proc.wait(timeout=5)
        except:
            daemon_proc.kill()
        if os.path.exists(daemon_socket):
            os.unlink(daemon_socket)

if __name__ == "__main__":
    success = test_immediate_daemon()
    if success:
        print("✅ IMMEDIATE TEST PASSED!")
        exit(0)
    else:
        print("❌ IMMEDIATE TEST FAILED!")
        exit(1)