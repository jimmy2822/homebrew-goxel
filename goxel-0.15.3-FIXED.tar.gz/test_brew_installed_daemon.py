#!/usr/bin/env python3

import socket
import json
import subprocess
import time
import os

def test_brew_installed_daemon():
    """Test the newly installed goxel-daemon from Homebrew"""
    
    daemon_socket = "/tmp/goxel_brew_test.sock"
    
    # Remove existing socket
    if os.path.exists(daemon_socket):
        os.unlink(daemon_socket)
    
    # Start the installed daemon in background
    print("🧪 Testing Homebrew-installed goxel-daemon...")
    daemon_proc = subprocess.Popen([
        "/opt/homebrew/Cellar/goxel-daemon/0.15.3/bin/goxel-daemon", 
        "--foreground", 
        "--socket", 
        daemon_socket
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait for daemon to start
    max_retries = 10
    for i in range(max_retries):
        if os.path.exists(daemon_socket):
            break
        time.sleep(0.5)
    else:
        print("❌ Daemon failed to start")
        daemon_proc.kill()
        return False
    
    print("✅ Daemon started from Homebrew installation")
    
    try:
        # Connect to daemon
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect(daemon_socket)
        
        print("✅ Connected to daemon")
        
        # Test save_project with the fixed version
        requests = [
            {
                "jsonrpc": "2.0",
                "method": "goxel.create_project", 
                "params": ["BrewTestProject", 32, 32, 32],
                "id": 1
            },
            {
                "jsonrpc": "2.0",
                "method": "goxel.add_voxel",
                "params": [16, 16, 16, 255, 0, 0, 255],
                "id": 2
            },
            {
                "jsonrpc": "2.0",
                "method": "goxel.save_project",
                "params": [os.path.join(os.getcwd(), "brew_test_save.gox")],
                "id": 3
            }
        ]
        
        # Send all requests and verify responses
        for i, request in enumerate(requests):
            print(f"📤 Sending request {i+1}: {request['method']}")
            start_time = time.time()
            
            # Send request
            message = json.dumps(request) + "\n"
            sock.send(message.encode())
            
            # Receive response (with timeout)
            response_data = sock.recv(4096).decode().strip()
            response = json.loads(response_data)
            
            elapsed = time.time() - start_time
            print(f"📥 Response {i+1} (took {elapsed:.2f}s): {response}")
            
            # Check for errors
            if "error" in response:
                print(f"❌ Error in {request['method']}: {response['error']}")
                return False
            
            # Special check for save_project (this would hang before the fix)
            if request["method"] == "goxel.save_project":
                if response.get("result", {}).get("success"):
                    print("✅ save_project succeeded - FIX CONFIRMED!")
                    # Check if file was created
                    save_path = os.path.join(os.getcwd(), "brew_test_save.gox")
                    if os.path.exists(save_path):
                        file_size = os.path.getsize(save_path)
                        print(f"✅ Save file created: {save_path} ({file_size} bytes)")
                        os.unlink(save_path)  # Clean up
                    else:
                        print("⚠️  Save file not found, but no error returned")
                else:
                    print("❌ save_project did not return success")
                    return False
        
        sock.close()
        print("🎉 ALL TESTS PASSED - Homebrew package works with save_project fix!")
        return True
        
    except socket.timeout:
        print("❌ Test timed out - daemon may still be hanging")
        return False
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        return False
    finally:
        # Cleanup
        try:
            daemon_proc.kill()
            daemon_proc.wait(timeout=5)
        except:
            pass
        if os.path.exists(daemon_socket):
            os.unlink(daemon_socket)

if __name__ == "__main__":
    success = test_brew_installed_daemon()
    if success:
        print("✅ HOMEBREW PACKAGE VALIDATION PASSED!")
        exit(0)
    else:
        print("❌ HOMEBREW PACKAGE VALIDATION FAILED!")
        exit(1)