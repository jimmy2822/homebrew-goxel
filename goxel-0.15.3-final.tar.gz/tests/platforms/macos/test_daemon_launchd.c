/**
 * macOS launchd integration tests for Goxel v14.0 daemon.
 * Tests daemon lifecycle management with launchd.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <sys/stat.h>
#include <pwd.h>
#include <assert.h>

#define LAUNCHD_PLIST_PATH "/tmp/com.goxel.daemon.test.plist"
#define TEST_DAEMON_PATH "/usr/local/bin/goxel-daemon"
#define TEST_SOCKET_PATH "/tmp/goxel-daemon-test.sock"
#define TEST_LOG_PATH "/tmp/goxel-daemon-test.log"

// Test result tracking
typedef struct {
    int total;
    int passed;
    int failed;
    char last_error[256];
} test_results_t;

static test_results_t results = {0, 0, 0, ""};

// Test macros
#define RUN_TEST(name) do { \
    printf("Running %s...\n", #name); \
    results.total++; \
    if (name()) { \
        printf("  ✓ PASSED\n"); \
        results.passed++; \
    } else { \
        printf("  ✗ FAILED: %s\n", results.last_error); \
        results.failed++; \
    } \
} while(0)

#define TEST_ASSERT(cond, msg) do { \
    if (!(cond)) { \
        snprintf(results.last_error, sizeof(results.last_error), "%s", msg); \
        return 0; \
    } \
} while(0)

// Create a test launchd plist
static int create_test_plist(void) {
    FILE *fp = fopen(LAUNCHD_PLIST_PATH, "w");
    if (!fp) return 0;
    
    fprintf(fp, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    fprintf(fp, "<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" ");
    fprintf(fp, "\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n");
    fprintf(fp, "<plist version=\"1.0\">\n");
    fprintf(fp, "<dict>\n");
    fprintf(fp, "    <key>Label</key>\n");
    fprintf(fp, "    <string>com.goxel.daemon.test</string>\n");
    fprintf(fp, "    <key>ProgramArguments</key>\n");
    fprintf(fp, "    <array>\n");
    fprintf(fp, "        <string>%s</string>\n", TEST_DAEMON_PATH);
    fprintf(fp, "        <string>--foreground</string>\n");
    fprintf(fp, "        <string>--socket</string>\n");
    fprintf(fp, "        <string>%s</string>\n", TEST_SOCKET_PATH);
    fprintf(fp, "        <string>--log-file</string>\n");
    fprintf(fp, "        <string>%s</string>\n", TEST_LOG_PATH);
    fprintf(fp, "    </array>\n");
    fprintf(fp, "    <key>RunAtLoad</key>\n");
    fprintf(fp, "    <false/>\n");
    fprintf(fp, "    <key>KeepAlive</key>\n");
    fprintf(fp, "    <true/>\n");
    fprintf(fp, "    <key>StandardOutPath</key>\n");
    fprintf(fp, "    <string>/tmp/goxel-daemon-test.stdout</string>\n");
    fprintf(fp, "    <key>StandardErrorPath</key>\n");
    fprintf(fp, "    <string>/tmp/goxel-daemon-test.stderr</string>\n");
    fprintf(fp, "    <key>SoftResourceLimits</key>\n");
    fprintf(fp, "    <dict>\n");
    fprintf(fp, "        <key>NumberOfFiles</key>\n");
    fprintf(fp, "        <integer>1024</integer>\n");
    fprintf(fp, "    </dict>\n");
    fprintf(fp, "</dict>\n");
    fprintf(fp, "</plist>\n");
    
    fclose(fp);
    return 1;
}

// Test 1: Plist validation
static int test_plist_validation(void) {
    // Create test plist
    TEST_ASSERT(create_test_plist(), "Failed to create test plist");
    
    // Validate plist format
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "plutil -lint %s >/dev/null 2>&1", LAUNCHD_PLIST_PATH);
    int ret = system(cmd);
    TEST_ASSERT(ret == 0, "Plist validation failed");
    
    unlink(LAUNCHD_PLIST_PATH);
    return 1;
}

// Test 2: Daemon binary check
static int test_daemon_binary_check(void) {
    // For testing, we'll check if the path would be valid
    struct stat st;
    
    // Check parent directory exists
    TEST_ASSERT(stat("/usr/local/bin", &st) == 0, "/usr/local/bin does not exist");
    TEST_ASSERT(S_ISDIR(st.st_mode), "/usr/local/bin is not a directory");
    
    // Check write permissions (would need for installation)
    // Skip actual permission check as it requires root
    printf("    Note: Actual installation would require root privileges\n");
    
    return 1;
}

// Test 3: Socket directory permissions
static int test_socket_directory_permissions(void) {
    struct stat st;
    
    // Check /tmp exists and is writable
    TEST_ASSERT(stat("/tmp", &st) == 0, "/tmp does not exist");
    TEST_ASSERT(S_ISDIR(st.st_mode), "/tmp is not a directory");
    TEST_ASSERT(st.st_mode & S_IWUSR, "/tmp is not writable by user");
    
    // Check if we can create files in /tmp
    char test_file[256];
    snprintf(test_file, sizeof(test_file), "/tmp/goxel_test_%d", getpid());
    
    FILE *fp = fopen(test_file, "w");
    TEST_ASSERT(fp != NULL, "Cannot create files in /tmp");
    fclose(fp);
    unlink(test_file);
    
    return 1;
}

// Test 4: KeepAlive configuration
static int test_keepalive_config(void) {
    TEST_ASSERT(create_test_plist(), "Failed to create test plist");
    
    // Check if KeepAlive is properly set
    FILE *fp = fopen(LAUNCHD_PLIST_PATH, "r");
    TEST_ASSERT(fp != NULL, "Cannot read plist file");
    
    char line[256];
    int found_keepalive = 0;
    int keepalive_value = 0;
    
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "<key>KeepAlive</key>")) {
            found_keepalive = 1;
            // Read next line for value
            if (fgets(line, sizeof(line), fp)) {
                if (strstr(line, "<true/>")) {
                    keepalive_value = 1;
                }
            }
            break;
        }
    }
    
    fclose(fp);
    
    TEST_ASSERT(found_keepalive, "KeepAlive key not found in plist");
    TEST_ASSERT(keepalive_value, "KeepAlive not set to true");
    
    unlink(LAUNCHD_PLIST_PATH);
    return 1;
}

// Test 5: Resource limits configuration
static int test_resource_limits(void) {
    TEST_ASSERT(create_test_plist(), "Failed to create test plist");
    
    // Check if resource limits are properly configured
    FILE *fp = fopen(LAUNCHD_PLIST_PATH, "r");
    TEST_ASSERT(fp != NULL, "Cannot read plist file");
    
    char line[256];
    int found_limits = 0;
    int found_files_limit = 0;
    
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "SoftResourceLimits")) {
            found_limits = 1;
        }
        if (found_limits && strstr(line, "NumberOfFiles")) {
            found_files_limit = 1;
            break;
        }
    }
    
    fclose(fp);
    
    TEST_ASSERT(found_limits, "SoftResourceLimits not found in plist");
    TEST_ASSERT(found_files_limit, "NumberOfFiles limit not configured");
    
    unlink(LAUNCHD_PLIST_PATH);
    return 1;
}

// Test 6: Log file configuration
static int test_log_configuration(void) {
    TEST_ASSERT(create_test_plist(), "Failed to create test plist");
    
    // Check if log paths are configured
    FILE *fp = fopen(LAUNCHD_PLIST_PATH, "r");
    TEST_ASSERT(fp != NULL, "Cannot read plist file");
    
    char line[256];
    int found_stdout = 0;
    int found_stderr = 0;
    
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "StandardOutPath")) {
            found_stdout = 1;
        }
        if (strstr(line, "StandardErrorPath")) {
            found_stderr = 1;
        }
    }
    
    fclose(fp);
    
    TEST_ASSERT(found_stdout, "StandardOutPath not configured");
    TEST_ASSERT(found_stderr, "StandardErrorPath not configured");
    
    unlink(LAUNCHD_PLIST_PATH);
    return 1;
}

// Test 7: User context
static int test_user_context(void) {
    struct passwd *pw = getpwuid(getuid());
    TEST_ASSERT(pw != NULL, "Cannot get user info");
    
    printf("    Current user: %s (UID: %d)\n", pw->pw_name, pw->pw_uid);
    printf("    Home directory: %s\n", pw->pw_dir);
    
    // Check if LaunchAgents directory exists
    char agents_dir[512];
    snprintf(agents_dir, sizeof(agents_dir), "%s/Library/LaunchAgents", pw->pw_dir);
    
    struct stat st;
    if (stat(agents_dir, &st) == 0) {
        printf("    LaunchAgents directory exists\n");
        TEST_ASSERT(S_ISDIR(st.st_mode), "LaunchAgents is not a directory");
    } else {
        printf("    LaunchAgents directory does not exist (would be created on install)\n");
    }
    
    return 1;
}

// Test 8: Signal handling compatibility
static int test_signal_compatibility(void) {
    // Test that we can handle signals that launchd might send
    sigset_t sigset;
    TEST_ASSERT(sigemptyset(&sigset) == 0, "sigemptyset failed");
    
    // Test common launchd signals
    TEST_ASSERT(sigaddset(&sigset, SIGTERM) == 0, "Cannot add SIGTERM");
    TEST_ASSERT(sigaddset(&sigset, SIGHUP) == 0, "Cannot add SIGHUP");
    TEST_ASSERT(sigaddset(&sigset, SIGUSR1) == 0, "Cannot add SIGUSR1");
    TEST_ASSERT(sigaddset(&sigset, SIGUSR2) == 0, "Cannot add SIGUSR2");
    
    printf("    Signal handling compatible with launchd\n");
    
    return 1;
}

int main(void) {
    printf("=== macOS launchd Integration Tests for Goxel v14.0 ===\n");
    printf("Platform: macOS\n");
    printf("Process: PID %d\n", getpid());
    printf("\n");
    
    printf("Note: Full launchd integration requires root privileges.\n");
    printf("These tests validate configuration and compatibility.\n\n");
    
    // Run all tests
    RUN_TEST(test_plist_validation);
    RUN_TEST(test_daemon_binary_check);
    RUN_TEST(test_socket_directory_permissions);
    RUN_TEST(test_keepalive_config);
    RUN_TEST(test_resource_limits);
    RUN_TEST(test_log_configuration);
    RUN_TEST(test_user_context);
    RUN_TEST(test_signal_compatibility);
    
    // Summary
    printf("\n=== Test Summary ===\n");
    printf("Total tests: %d\n", results.total);
    printf("Passed: %d\n", results.passed);
    printf("Failed: %d\n", results.failed);
    printf("Success rate: %.1f%%\n", 
           results.total > 0 ? (100.0 * results.passed / results.total) : 0);
    
    return results.failed > 0 ? 1 : 0;
}