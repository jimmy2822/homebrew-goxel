/**
 * macOS-specific Unix domain socket tests for Goxel v14.0 daemon.
 * Tests socket creation, permissions, and platform-specific behaviors.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <assert.h>
#include <mach/mach_time.h>
#include <pthread.h>

#define TEST_SOCKET_PATH "/tmp/goxel_test_macos.sock"
#define MAX_PATH_LEN 104  // macOS limit for Unix socket paths

// Test result tracking
typedef struct {
    int total;
    int passed;
    int failed;
    char last_error[256];
} test_results_t;

static test_results_t results = {0, 0, 0, ""};

// Timing utilities for macOS
static uint64_t get_time_ns(void) {
    static mach_timebase_info_data_t timebase;
    if (timebase.denom == 0) {
        mach_timebase_info(&timebase);
    }
    uint64_t time = mach_absolute_time();
    return time * timebase.numer / timebase.denom;
}

// Test macros
#define RUN_TEST(name) do { \
    printf("Running %s...\n", #name); \
    results.total++; \
    if (name()) { \
        printf("  ✓ PASSED\n"); \
        results.passed++; \
    } else { \
        printf("  ✗ FAILED: %s\n", results.last_error); \
        results.failed++; \
    } \
} while(0)

#define TEST_ASSERT(cond, msg) do { \
    if (!(cond)) { \
        snprintf(results.last_error, sizeof(results.last_error), "%s", msg); \
        return 0; \
    } \
} while(0)

// Test 1: Basic socket creation
static int test_socket_creation(void) {
    unlink(TEST_SOCKET_PATH);
    
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TEST_SOCKET_PATH, sizeof(addr.sun_path) - 1);
    
    int ret = bind(fd, (struct sockaddr*)&addr, sizeof(addr));
    TEST_ASSERT(ret == 0, "Failed to bind socket");
    
    struct stat st;
    TEST_ASSERT(stat(TEST_SOCKET_PATH, &st) == 0, "Socket file not created");
    TEST_ASSERT(S_ISSOCK(st.st_mode), "File is not a socket");
    
    close(fd);
    unlink(TEST_SOCKET_PATH);
    return 1;
}

// Test 2: Path length limits (macOS specific)
static int test_path_length_limits(void) {
    // Test maximum path length (104 chars on macOS)
    char long_path[256];
    memset(long_path, 'a', sizeof(long_path));
    long_path[MAX_PATH_LEN - 1] = '\0';
    long_path[0] = '/';
    long_path[1] = 't';
    long_path[2] = 'm';
    long_path[3] = 'p';
    long_path[4] = '/';
    
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, long_path, sizeof(addr.sun_path) - 1);
    
    // This should succeed at the limit
    int ret = bind(fd, (struct sockaddr*)&addr, sizeof(addr));
    if (ret == 0) {
        unlink(long_path);
    }
    close(fd);
    
    // Test over the limit
    long_path[MAX_PATH_LEN] = 'x';
    long_path[MAX_PATH_LEN + 1] = '\0';
    
    fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket for over-limit test");
    
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, long_path, sizeof(addr.sun_path) - 1);
    
    ret = bind(fd, (struct sockaddr*)&addr, sizeof(addr));
    TEST_ASSERT(ret == -1, "Bind should fail with path too long");
    TEST_ASSERT(errno == ENAMETOOLONG || errno == EINVAL, "Wrong error for long path");
    
    close(fd);
    return 1;
}

// Test 3: Socket permissions
static int test_socket_permissions(void) {
    unlink(TEST_SOCKET_PATH);
    
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TEST_SOCKET_PATH, sizeof(addr.sun_path) - 1);
    
    TEST_ASSERT(bind(fd, (struct sockaddr*)&addr, sizeof(addr)) == 0, "Bind failed");
    
    // Set specific permissions
    mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP;
    TEST_ASSERT(chmod(TEST_SOCKET_PATH, mode) == 0, "chmod failed");
    
    struct stat st;
    TEST_ASSERT(stat(TEST_SOCKET_PATH, &st) == 0, "stat failed");
    TEST_ASSERT((st.st_mode & 0777) == mode, "Permissions not set correctly");
    
    close(fd);
    unlink(TEST_SOCKET_PATH);
    return 1;
}

// Test 4: Concurrent connections
static int test_concurrent_connections(void) {
    unlink(TEST_SOCKET_PATH);
    
    // Create server socket
    int server_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(server_fd >= 0, "Failed to create server socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TEST_SOCKET_PATH, sizeof(addr.sun_path) - 1);
    
    TEST_ASSERT(bind(server_fd, (struct sockaddr*)&addr, sizeof(addr)) == 0, "Bind failed");
    TEST_ASSERT(listen(server_fd, 128) == 0, "Listen failed");
    
    // Test multiple client connections
    int client_fds[10];
    for (int i = 0; i < 10; i++) {
        client_fds[i] = socket(AF_UNIX, SOCK_STREAM, 0);
        TEST_ASSERT(client_fds[i] >= 0, "Failed to create client socket");
        
        // Non-blocking connect
        int ret = connect(client_fds[i], (struct sockaddr*)&addr, sizeof(addr));
        if (ret == -1 && errno != EINPROGRESS) {
            char msg[256];
            snprintf(msg, sizeof(msg), "Connect failed for client %d: %s", i, strerror(errno));
            TEST_ASSERT(0, msg);
        }
    }
    
    // Accept connections
    for (int i = 0; i < 10; i++) {
        int client = accept(server_fd, NULL, NULL);
        TEST_ASSERT(client >= 0, "Accept failed");
        close(client);
    }
    
    // Cleanup
    for (int i = 0; i < 10; i++) {
        close(client_fds[i]);
    }
    close(server_fd);
    unlink(TEST_SOCKET_PATH);
    
    return 1;
}

// Test 5: Performance benchmark
static int test_socket_performance(void) {
    unlink(TEST_SOCKET_PATH);
    
    // Measure socket creation time
    uint64_t start = get_time_ns();
    
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TEST_SOCKET_PATH, sizeof(addr.sun_path) - 1);
    
    TEST_ASSERT(bind(fd, (struct sockaddr*)&addr, sizeof(addr)) == 0, "Bind failed");
    TEST_ASSERT(listen(fd, 5) == 0, "Listen failed");
    
    uint64_t end = get_time_ns();
    double elapsed_ms = (end - start) / 1000000.0;
    
    printf("    Socket creation time: %.3f ms\n", elapsed_ms);
    TEST_ASSERT(elapsed_ms < 10.0, "Socket creation too slow");
    
    // Test accept/connect performance
    pthread_t thread;
    pthread_create(&thread, NULL, (void*)accept, (void*)(intptr_t)fd);
    
    int client_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(client_fd >= 0, "Failed to create client socket");
    
    start = get_time_ns();
    TEST_ASSERT(connect(client_fd, (struct sockaddr*)&addr, sizeof(addr)) == 0, "Connect failed");
    end = get_time_ns();
    
    elapsed_ms = (end - start) / 1000000.0;
    printf("    Connection time: %.3f ms\n", elapsed_ms);
    TEST_ASSERT(elapsed_ms < 5.0, "Connection too slow");
    
    close(client_fd);
    close(fd);
    pthread_cancel(thread);
    pthread_join(thread, NULL);
    unlink(TEST_SOCKET_PATH);
    
    return 1;
}

// Test 6: File descriptor limits
static int test_fd_limits(void) {
    // Get current limit
    struct rlimit rlim;
    getrlimit(RLIMIT_NOFILE, &rlim);
    printf("    Current FD limit: %llu (soft), %llu (hard)\n", 
           (unsigned long long)rlim.rlim_cur, (unsigned long long)rlim.rlim_max);
    
    // Try to create many sockets
    int fds[256];
    int count = 0;
    
    for (int i = 0; i < 256; i++) {
        fds[i] = socket(AF_UNIX, SOCK_STREAM, 0);
        if (fds[i] < 0) {
            break;
        }
        count++;
    }
    
    printf("    Created %d sockets\n", count);
    TEST_ASSERT(count >= 200, "Could not create enough sockets");
    
    // Cleanup
    for (int i = 0; i < count; i++) {
        close(fds[i]);
    }
    
    return 1;
}

// Test 7: Socket cleanup on crash
static int test_socket_cleanup(void) {
    unlink(TEST_SOCKET_PATH);
    
    // Create socket
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TEST_SOCKET_PATH, sizeof(addr.sun_path) - 1);
    
    TEST_ASSERT(bind(fd, (struct sockaddr*)&addr, sizeof(addr)) == 0, "Bind failed");
    
    // Verify file exists
    struct stat st;
    TEST_ASSERT(stat(TEST_SOCKET_PATH, &st) == 0, "Socket file not created");
    
    // Simulate "crash" by closing FD without unlink
    close(fd);
    
    // File should still exist
    TEST_ASSERT(stat(TEST_SOCKET_PATH, &st) == 0, "Socket file removed on close");
    
    // Try to bind again (should fail)
    fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create second socket");
    
    int ret = bind(fd, (struct sockaddr*)&addr, sizeof(addr));
    TEST_ASSERT(ret == -1 && errno == EADDRINUSE, "Bind should fail with EADDRINUSE");
    
    close(fd);
    unlink(TEST_SOCKET_PATH);
    return 1;
}

int main(void) {
    printf("=== macOS Unix Socket Tests for Goxel v14.0 ===\n");
    printf("Platform: macOS ARM64\n");
    printf("Process: PID %d\n", getpid());
    printf("\n");
    
    // Run all tests
    RUN_TEST(test_socket_creation);
    RUN_TEST(test_path_length_limits);
    RUN_TEST(test_socket_permissions);
    RUN_TEST(test_concurrent_connections);
    RUN_TEST(test_socket_performance);
    RUN_TEST(test_fd_limits);
    RUN_TEST(test_socket_cleanup);
    
    // Summary
    printf("\n=== Test Summary ===\n");
    printf("Total tests: %d\n", results.total);
    printf("Passed: %d\n", results.passed);
    printf("Failed: %d\n", results.failed);
    printf("Success rate: %.1f%%\n", 
           results.total > 0 ? (100.0 * results.passed / results.total) : 0);
    
    return results.failed > 0 ? 1 : 0;
}