#!/bin/bash

# Kill any existing daemon
pkill -f goxel-daemon 2>/dev/null
sleep 0.5

# Start daemon with output to file
echo "Starting daemon with debug output..."
./goxel-daemon --foreground --socket /tmp/test_debug.sock --verbose > daemon_debug.log 2>&1 &
DAEMON_PID=$!

# Wait for daemon to start
sleep 2

# Send a request
echo "Sending test request..."
python3 -c "
import socket, json
s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
try:
    s.connect('/tmp/test_debug.sock')
    print('Connected')
    req = {'jsonrpc':'2.0','method':'goxel.create_project','params':['Test',16,16,16],'id':1}
    s.send(json.dumps(req).encode() + b'\\n')
    print('Sent request')
    s.settimeout(2.0)
    resp = s.recv(4096)
    print('Response:', resp)
except Exception as e:
    print('Error:', e)
finally:
    s.close()
"

# Give it a moment
sleep 1

# Kill daemon
kill $DAEMON_PID 2>/dev/null

# Show daemon output
echo -e "\n=== Daemon output ==="
cat daemon_debug.log