#!/usr/bin/env python3
"""
Simple test for protocol detection fix
"""
import socket
import json
import time

def test_protocol():
    try:
        # Connect to daemon
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect("/opt/homebrew/var/run/goxel/goxel.sock")
        
        # Test standard JSON-RPC with whitespace (this should now work)
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.get_status",
            "id": 1
        }
        
        # Use normal JSON formatting with spaces
        message = json.dumps(request, separators=(',', ': ')) + '\n'
        print(f"Sending: {repr(message)}")
        
        sock.send(message.encode())
        
        # Read response
        response = sock.recv(4096).decode().strip()
        print(f"Response: {response}")
        
        # Try to parse response
        resp_obj = json.loads(response)
        if 'result' in resp_obj:
            print("✅ SUCCESS: Standard JSON-RPC format works!")
            return True
        elif 'error' in resp_obj:
            print(f"✅ Got response (with error): {resp_obj['error']}")
            return True
        else:
            print("❌ Unexpected response format")
            return False
            
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False
    finally:
        sock.close()

if __name__ == "__main__":
    print("Testing protocol detection fix...")
    success = test_protocol()
    if success:
        print("Protocol detection fix is working!")
    else:
        print("Protocol detection fix may need more work.")