#!/bin/bash
# Quick test for connection reuse

echo "Starting Goxel daemon..."
./goxel-daemon --foreground --socket /tmp/goxel_test.sock &
DAEMON_PID=$!

# Wait for daemon to start
sleep 1

echo -e "\nTesting connection reuse with 5 requests..."
python3 - << 'EOF'
import json
import socket

sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
sock.connect("/tmp/goxel_test.sock")

success_count = 0
for i in range(5):
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.create_project",
        "params": [f"Test{i}", 8, 8, 8],
        "id": i + 1
    }
    
    sock.send((json.dumps(request) + "\n").encode())
    
    response = b""
    while b"\n" not in response:
        chunk = sock.recv(1024)
        if not chunk:
            print(f"❌ Connection lost at request {i+1}")
            break
        response += chunk
    
    if response:
        print(f"✅ Request {i+1}: Got response")
        success_count += 1
    else:
        print(f"❌ Request {i+1}: No response")
        break

sock.close()
print(f"\n{'✅' if success_count == 5 else '❌'} Completed {success_count}/5 requests on single connection")
EOF

# Clean up
echo -e "\nStopping daemon..."
kill $DAEMON_PID 2>/dev/null
wait $DAEMON_PID 2>/dev/null
rm -f /tmp/goxel_test.sock

echo "Test complete!"