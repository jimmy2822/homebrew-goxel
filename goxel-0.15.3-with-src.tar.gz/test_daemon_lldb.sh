#!/bin/bash

# Kill any existing daemon
pkill -f goxel-daemon 2>/dev/null
sleep 0.5

# Create LLDB script
cat > lldb_commands.txt << 'EOF'
run --foreground --socket /tmp/lldb_test.sock --verbose
EOF

# Run daemon under LLDB
echo "Starting daemon under LLDB..."
lldb -s lldb_commands.txt ./goxel-daemon &
LLDB_PID=$!

# Wait for daemon to start
sleep 3

# Send test request
echo "Sending test request..."
python3 -c "
import socket, json
try:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect('/tmp/lldb_test.sock')
    print('Connected')
    req = {'jsonrpc':'2.0','method':'echo','params':['test'],'id':1}
    s.send(json.dumps(req).encode() + b'\\n')
    print('Request sent')
    s.settimeout(1.0)
    resp = s.recv(4096)
    print('Response:', resp)
except Exception as e:
    print('Error:', e)
"

# Give LLDB time to catch crash
sleep 2

# Get backtrace
echo -e "\nbt\nquit\ny" | lldb -p $(pgrep -f goxel-daemon) 2>/dev/null || true

# Cleanup
pkill -f lldb 2>/dev/null
pkill -f goxel-daemon 2>/dev/null
rm -f lldb_commands.txt