//
//  goxel-Bridging-Header.h
//  goxel
//
//  Created by Guillaume Chereau on 10/16/15.
//  Copyright © 2015 Noctua Software Limited. All rights reserved.
//

#ifndef goxel_Bridging_Header_h
#define goxel_Bridging_Header_h

#ifndef DEBUG
#   define DEBUG 0
#endif

#include "config.h"
#include "goxel.h"

#endif /* goxel_Bridging_Header_h */
