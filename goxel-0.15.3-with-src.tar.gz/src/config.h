/* Goxel configuration file for daemon build */
#ifndef CONFIG_H
#define CONFIG_H

#define GOXEL_VERSION_STR "0.15.3"
#define GOXEL_DAEMON_MODE 1

/* Build configuration */
#define GOXEL_SOUND 0
#define GOXEL_GUI 0
#define GOXEL_C_API 0
#define GOXEL_DAEMON 1
#define GOXEL_YOCTO 1

/* Platform detection */
#ifdef __APPLE__
#define GOXEL_MACOS 1
#endif

#ifdef __linux__
#define GOXEL_LINUX 1
#endif

#endif /* CONFIG_H */