#!/usr/bin/env python3
"""Test connection reuse with different methods to avoid create_project issue"""

import json
import socket
import time

def test_connection_reuse_varied(socket_path="/tmp/goxel_test3.sock", num_requests=5):
    """Test sending multiple different requests over a single connection"""
    
    print(f"Connecting to {socket_path}")
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    
    try:
        sock.connect(socket_path)
        print("Connected successfully")
        
        # First create one project
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.create_project",
            "params": ["TestProject", 16, 16, 16],
            "id": 1
        }
        
        request_str = json.dumps(request) + "\n"
        print(f"\nRequest 1: {request_str.strip()}")
        sock.send(request_str.encode())
        
        # Receive response
        response = b""
        while True:
            chunk = sock.recv(1024)
            if not chunk:
                print("Connection closed by server")
                return False
            response += chunk
            if b"\n" in response:
                break
        
        response_str = response.decode().strip()
        print(f"Response 1: {response_str}")
        
        # Now use different methods that don't create projects
        methods = [
            ("goxel.get_project_info", []),
            ("goxel.list_layers", []),
            ("goxel.create_layer", ["TestLayer"]),
            ("goxel.list_layers", [])
        ]
        
        for i, (method, params) in enumerate(methods, start=2):
            request = {
                "jsonrpc": "2.0",
                "method": method,
                "params": params,
                "id": i
            }
            
            request_str = json.dumps(request) + "\n"
            print(f"\nRequest {i}: {method}")
            sock.send(request_str.encode())
            
            # Receive response
            response = b""
            while True:
                chunk = sock.recv(1024)
                if not chunk:
                    print(f"Connection closed at request {i}")
                    return False
                response += chunk
                if b"\n" in response:
                    break
            
            response_str = response.decode().strip()
            print(f"Response {i}: {response_str[:100]}...")
            
            time.sleep(0.05)  # Small delay between requests
        
        print(f"\n✅ Successfully sent {num_requests} requests over single connection!")
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False
    finally:
        sock.close()

if __name__ == "__main__":
    import sys
    
    socket_path = sys.argv[1] if len(sys.argv) > 1 else "/tmp/goxel_test3.sock"
    
    success = test_connection_reuse_varied(socket_path)
    sys.exit(0 if success else 1)