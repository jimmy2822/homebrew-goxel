#!/bin/bash

# Kill any existing daemon
pkill -f goxel-daemon 2>/dev/null
sleep 0.5

# Start daemon under GDB
echo "Starting daemon under GDB..."
gdb ./goxel-daemon << 'EOF' > gdb_output.log 2>&1 &
set pagination off
run --foreground --socket /tmp/gdb_test.sock --verbose
EOF

# Wait for daemon to start
sleep 3

# Send test request in background
python3 -c "
import socket, json, time
time.sleep(1)
try:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect('/tmp/gdb_test.sock')
    req = {'jsonrpc':'2.0','method':'goxel.create_project','params':['Test',16,16,16],'id':1}
    s.send(json.dumps(req).encode() + b'\\n')
except: pass
" &

# Wait for crash
sleep 3

# Get backtrace from GDB
echo -e "bt\ninfo registers\nquit\ny" | gdb -p $(pgrep -f goxel-daemon) 2>/dev/null > gdb_backtrace.log || true

# Show results
echo "=== GDB Output ==="
cat gdb_output.log | tail -50
echo -e "\n=== Backtrace ==="
cat gdb_backtrace.log | grep -A30 "#0"

# Cleanup
pkill -f gdb 2>/dev/null
pkill -f goxel-daemon 2>/dev/null
rm -f gdb_output.log gdb_backtrace.log