#!/usr/bin/env python3
"""
Concurrent stress test for Goxel daemon
Tests daemon stability under various concurrent load scenarios
"""

import socket
import json
import threading
import time
import sys
import os
import subprocess
import signal
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
import statistics
import argparse
from collections import defaultdict

@dataclass
class TestResult:
    """Result of a single test request"""
    thread_id: int
    request_id: int
    method: str
    success: bool
    error: Optional[str]
    latency_ms: float
    timestamp: float

class DaemonStressTest:
    def __init__(self, socket_path: str, daemon_path: str):
        self.socket_path = socket_path
        self.daemon_path = daemon_path
        self.daemon_process = None
        self.results: List[TestResult] = []
        self.results_lock = threading.Lock()
        self.request_counter = 0
        self.counter_lock = threading.Lock()
        
    def start_daemon(self):
        """Start the daemon process"""
        print(f"Starting daemon at {self.socket_path}")
        self.daemon_process = subprocess.Popen(
            [self.daemon_path, "--foreground", "--socket", self.socket_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        # Give daemon time to initialize
        time.sleep(1)
        
    def stop_daemon(self):
        """Stop the daemon process"""
        if self.daemon_process:
            print("Stopping daemon...")
            self.daemon_process.terminate()
            try:
                self.daemon_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.daemon_process.kill()
                self.daemon_process.wait()
            
    def get_next_request_id(self):
        """Get next request ID atomically"""
        with self.counter_lock:
            self.request_counter += 1
            return self.request_counter
            
    def send_request(self, method: str, params: List[Any]) -> Dict[str, Any]:
        """Send a JSON-RPC request and get response"""
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(5.0)  # 5 second timeout
        
        try:
            sock.connect(self.socket_path)
            
            request = {
                "jsonrpc": "2.0",
                "method": method,
                "params": params,
                "id": self.get_next_request_id()
            }
            
            # Send request
            sock.send(json.dumps(request).encode() + b'\n')
            
            # Receive response
            response_data = b""
            while True:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                response_data += chunk
                if b'\n' in response_data:
                    break
                    
            response = json.loads(response_data.decode().strip())
            return response
            
        finally:
            sock.close()
            
    def worker_thread(self, thread_id: int, num_requests: int, test_scenario: str):
        """Worker thread that sends requests"""
        for i in range(num_requests):
            try:
                start_time = time.time()
                
                # Choose request based on scenario
                if test_scenario == "create_only":
                    method = "goxel.create_project"
                    params = [f"Project_{thread_id}_{i}", 16, 16, 16]
                elif test_scenario == "mixed":
                    # Mix of different operations
                    ops = [
                        ("goxel.create_project", [f"Project_{thread_id}_{i}", 16, 16, 16]),
                        ("goxel.add_voxels", {"voxels": [{"position": [8, 8, 8], "color": [255, 0, 0, 255]}]}),
                        ("goxel.save_file", [f"/tmp/test_{thread_id}_{i}.gox"]),
                        ("goxel.list_layers", []),
                    ]
                    method, params = ops[i % len(ops)]
                elif test_scenario == "heavy":
                    # Heavy operations with many voxels
                    method = "goxel.add_voxels"
                    voxels = []
                    for x in range(5):
                        for y in range(5):
                            for z in range(5):
                                voxels.append({
                                    "position": [x, y, z],
                                    "color": [x*50, y*50, z*50, 255]
                                })
                    params = {"voxels": voxels}
                else:
                    raise ValueError(f"Unknown scenario: {test_scenario}")
                
                response = self.send_request(method, params)
                end_time = time.time()
                latency_ms = (end_time - start_time) * 1000
                
                # Check response
                success = "result" in response and not "error" in response
                error = response.get("error", {}).get("message") if "error" in response else None
                
                result = TestResult(
                    thread_id=thread_id,
                    request_id=response.get("id", -1),
                    method=method,
                    success=success,
                    error=error,
                    latency_ms=latency_ms,
                    timestamp=end_time
                )
                
                with self.results_lock:
                    self.results.append(result)
                    
            except Exception as e:
                result = TestResult(
                    thread_id=thread_id,
                    request_id=-1,
                    method=method if 'method' in locals() else "unknown",
                    success=False,
                    error=str(e),
                    latency_ms=0,
                    timestamp=time.time()
                )
                with self.results_lock:
                    self.results.append(result)
                    
            # Small delay between requests
            time.sleep(0.01)
            
    def run_test(self, num_threads: int, requests_per_thread: int, scenario: str):
        """Run concurrent test with specified parameters"""
        print(f"\nRunning test: {num_threads} threads, {requests_per_thread} requests each, scenario: {scenario}")
        
        self.results.clear()
        self.request_counter = 0
        
        # Create and start threads
        threads = []
        start_time = time.time()
        
        for i in range(num_threads):
            thread = threading.Thread(
                target=self.worker_thread,
                args=(i, requests_per_thread, scenario)
            )
            threads.append(thread)
            thread.start()
            
        # Wait for all threads to complete
        for thread in threads:
            thread.join()
            
        end_time = time.time()
        total_time = end_time - start_time
        
        # Analyze results
        self.analyze_results(total_time)
        
    def analyze_results(self, total_time: float):
        """Analyze and print test results"""
        if not self.results:
            print("No results to analyze!")
            return
            
        successful = [r for r in self.results if r.success]
        failed = [r for r in self.results if not r.success]
        
        print(f"\n=== Test Results ===")
        print(f"Total requests: {len(self.results)}")
        print(f"Successful: {len(successful)} ({len(successful)/len(self.results)*100:.1f}%)")
        print(f"Failed: {len(failed)} ({len(failed)/len(self.results)*100:.1f}%)")
        print(f"Total time: {total_time:.2f}s")
        print(f"Throughput: {len(self.results)/total_time:.1f} req/s")
        
        if successful:
            latencies = [r.latency_ms for r in successful]
            print(f"\nLatency statistics (ms):")
            print(f"  Min: {min(latencies):.1f}")
            print(f"  Max: {max(latencies):.1f}")
            print(f"  Mean: {statistics.mean(latencies):.1f}")
            print(f"  Median: {statistics.median(latencies):.1f}")
            if len(latencies) > 1:
                print(f"  Std Dev: {statistics.stdev(latencies):.1f}")
                
        if failed:
            print(f"\nErrors by type:")
            error_counts = defaultdict(int)
            for r in failed:
                error_counts[r.error or "Unknown"] += 1
            for error, count in sorted(error_counts.items(), key=lambda x: x[1], reverse=True):
                print(f"  {error}: {count}")
                
    def run_all_tests(self):
        """Run comprehensive test suite"""
        test_scenarios = [
            # (threads, requests_per_thread, scenario)
            (1, 10, "create_only"),      # Baseline single thread
            (5, 10, "create_only"),      # Light concurrent load
            (10, 10, "create_only"),     # Medium concurrent load
            (20, 10, "create_only"),     # Heavy concurrent load
            (5, 20, "mixed"),            # Mixed operations
            (10, 20, "mixed"),           # Mixed operations higher load
            (5, 5, "heavy"),             # Heavy voxel operations
        ]
        
        for threads, requests, scenario in test_scenarios:
            try:
                self.run_test(threads, requests, scenario)
                time.sleep(2)  # Pause between tests
            except Exception as e:
                print(f"Test failed: {e}")
                
def main():
    parser = argparse.ArgumentParser(description="Goxel daemon concurrent stress test")
    parser.add_argument("--daemon", default="./goxel-daemon", help="Path to daemon executable")
    parser.add_argument("--socket", default="/tmp/goxel_stress_test.sock", help="Socket path")
    parser.add_argument("--threads", type=int, help="Number of threads (overrides default tests)")
    parser.add_argument("--requests", type=int, help="Requests per thread (overrides default tests)")
    parser.add_argument("--scenario", choices=["create_only", "mixed", "heavy"], 
                       help="Test scenario (overrides default tests)")
    
    args = parser.parse_args()
    
    # Clean up any existing socket
    if os.path.exists(args.socket):
        os.unlink(args.socket)
        
    tester = DaemonStressTest(args.socket, args.daemon)
    
    try:
        tester.start_daemon()
        
        if args.threads and args.requests and args.scenario:
            # Run custom test
            tester.run_test(args.threads, args.requests, args.scenario)
        else:
            # Run default test suite
            tester.run_all_tests()
            
    finally:
        tester.stop_daemon()
        # Clean up socket
        if os.path.exists(args.socket):
            os.unlink(args.socket)

if __name__ == "__main__":
    main()