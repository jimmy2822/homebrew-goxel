#!/usr/bin/env python3
"""
Test script for bulk voxel reading operations in Goxel daemon.

Tests the new JSON-RPC methods:
- goxel.get_voxels_region
- goxel.get_layer_voxels
- goxel.get_bounding_box
"""

import socket
import json
import sys
import time

def send_request(sock, method, params=None, id=1):
    """Send a JSON-RPC request and receive the response."""
    request = {
        "jsonrpc": "2.0",
        "method": method,
        "id": id
    }
    if params:
        request["params"] = params
    
    request_str = json.dumps(request)
    sock.sendall(request_str.encode() + b'\n')
    
    # Receive response
    response = b""
    while not response.endswith(b'\n'):
        chunk = sock.recv(4096)
        if not chunk:
            break
        response += chunk
    
    return json.loads(response.decode())

def main():
    # Connect to daemon
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    
    try:
        sock.connect("/tmp/goxel.sock")
    except ConnectionRefusedError:
        print("Error: Cannot connect to Goxel daemon")
        print("Make sure the daemon is running with: ./goxel-daemon --foreground --socket /tmp/goxel.sock")
        sys.exit(1)
    
    print("Connected to Goxel daemon")
    
    # Create a new project
    print("\n1. Creating new project...")
    response = send_request(sock, "goxel.create_project", {
        "width": 128,
        "height": 128,
        "depth": 128
    })
    print(f"Response: {response}")
    
    # Add some test voxels in a 10x10x10 cube
    print("\n2. Adding test voxels...")
    for x in range(10, 20):
        for y in range(10, 20):
            for z in range(10, 20):
                # Create a gradient color based on position
                r = int((x - 10) * 255 / 10)
                g = int((y - 10) * 255 / 10)
                b = int((z - 10) * 255 / 10)
                
                response = send_request(sock, "goxel.add_voxel", {
                    "x": x,
                    "y": y,
                    "z": z,
                    "r": r,
                    "g": g,
                    "b": b,
                    "a": 255
                }, id=1000 + x*100 + y*10 + z)
    
    print("Added 1000 test voxels")
    
    # Test 1: Get voxels in a region
    print("\n3. Testing get_voxels_region...")
    response = send_request(sock, "goxel.get_voxels_region", {
        "min": [12, 12, 12],
        "max": [17, 17, 17],
        "limit": 100
    })
    
    if "result" in response:
        result = response["result"]
        print(f"Found {result['count']} voxels in region")
        if result["count"] > 0:
            print(f"Bounding box: {result.get('bbox', 'N/A')}")
            print(f"First 3 voxels: {result['voxels'][:3]}")
    else:
        print(f"Error: {response}")
    
    # Test 2: Get all layer voxels
    print("\n4. Testing get_layer_voxels...")
    response = send_request(sock, "goxel.get_layer_voxels", {
        "layer_id": -1,  # Active layer
        "limit": 50
    })
    
    if "result" in response:
        result = response["result"]
        print(f"Found {result['count']} voxels in layer")
        print(f"Truncated: {result.get('truncated', False)}")
    else:
        print(f"Error: {response}")
    
    # Test 3: Get voxels with color filter
    print("\n5. Testing get_layer_voxels with color filter...")
    response = send_request(sock, "goxel.get_layer_voxels", {
        "layer_id": -1,
        "color_filter": [127, 127, 127, 255],  # Middle gray
        "limit": 10
    })
    
    if "result" in response:
        result = response["result"]
        print(f"Found {result['count']} voxels matching color filter")
        if result["count"] > 0:
            print(f"Matching voxels: {result['voxels'][:3]}")
    else:
        print(f"Error: {response}")
    
    # Test 4: Get bounding box
    print("\n6. Testing get_bounding_box...")
    response = send_request(sock, "goxel.get_bounding_box", {
        "layer_id": -1,
        "exact": True
    })
    
    if "result" in response:
        result = response["result"]
        if not result["empty"]:
            print(f"Bounding box: min={result['min']}, max={result['max']}")
            print(f"Dimensions: {result['dimensions']}")
        else:
            print("Layer is empty")
    else:
        print(f"Error: {response}")
    
    # Test 5: Pagination
    print("\n7. Testing pagination...")
    all_voxels = []
    offset = 0
    limit = 200
    
    while True:
        response = send_request(sock, "goxel.get_layer_voxels", {
            "layer_id": -1,
            "offset": offset,
            "limit": limit
        })
        
        if "result" in response:
            result = response["result"]
            all_voxels.extend(result["voxels"])
            print(f"Fetched {len(result['voxels'])} voxels (offset={offset})")
            
            if not result.get("truncated", False) or len(result["voxels"]) < limit:
                break
            
            offset += len(result["voxels"])
        else:
            print(f"Error: {response}")
            break
    
    print(f"Total voxels fetched: {len(all_voxels)}")
    
    # Performance test
    print("\n8. Performance test...")
    start_time = time.time()
    
    response = send_request(sock, "goxel.get_layer_voxels", {
        "layer_id": -1,
        "limit": 10000
    })
    
    elapsed = time.time() - start_time
    
    if "result" in response:
        result = response["result"]
        print(f"Fetched {result['count']} voxels in {elapsed:.3f} seconds")
        print(f"Rate: {result['count'] / elapsed:.0f} voxels/second")
    
    sock.close()
    print("\nAll tests completed!")

if __name__ == "__main__":
    main()