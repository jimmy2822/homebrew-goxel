#!/usr/bin/env python3
"""Test script for verifying non-blocking script execution in Goxel daemon."""

import json
import socket
import time
import threading
import sys

def send_json_rpc_request(sock, method, params=None, request_id=1):
    """Send a JSON-RPC request and return the response."""
    request = {
        "jsonrpc": "2.0",
        "method": method,
        "id": request_id
    }
    if params:
        request["params"] = params
    
    # Send request
    request_str = json.dumps(request) + "\n"
    sock.sendall(request_str.encode())
    
    # Read response
    response = b""
    while True:
        chunk = sock.recv(4096)
        if not chunk:
            break
        response += chunk
        if b"\n" in response:
            break
    
    return json.loads(response.decode().strip())

def test_synchronous_execution():
    """Test synchronous script execution."""
    print("Testing synchronous script execution...")
    
    # Connect to daemon
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect("/tmp/goxel.sock")
    
    # Simple script that adds a voxel
    script_code = """
    // Test script that adds a red voxel at position (10, 10, 10)
    var result = goxel.addVoxel(10, 10, 10, [255, 0, 0, 255]);
    console.log("Added voxel at (10, 10, 10): " + result);
    """
    
    # Execute script
    response = send_json_rpc_request(sock, "goxel.execute_script", {
        "script": script_code,
        "name": "test_add_voxel.js"
    })
    
    print(f"Response: {json.dumps(response, indent=2)}")
    
    # Verify result
    if "result" in response:
        assert response["result"]["success"] == True, "Script execution should succeed"
        print("✓ Synchronous script execution successful")
    else:
        print(f"✗ Script execution failed: {response}")
    
    sock.close()

def test_concurrent_execution():
    """Test multiple concurrent script executions."""
    print("\nTesting concurrent script execution...")
    
    def execute_script(script_id, delay_ms):
        """Execute a script with a delay."""
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect("/tmp/goxel.sock")
        
        # Script that simulates work with a delay
        script_code = f"""
        // Script {script_id} with {delay_ms}ms delay
        console.log("Script {script_id} starting...");
        
        // Add voxel at unique position
        var x = {10 + script_id * 5};
        var result = goxel.addVoxel(x, 10, 10, [255, {script_id * 50}, 0, 255]);
        
        console.log("Script {script_id} completed, added voxel at (" + x + ", 10, 10)");
        """
        
        start_time = time.time()
        response = send_json_rpc_request(sock, "goxel.execute_script", {
            "script": script_code,
            "name": f"concurrent_test_{script_id}.js",
            "timeout_ms": 5000
        }, request_id=script_id)
        
        elapsed = time.time() - start_time
        print(f"Script {script_id} completed in {elapsed:.3f}s: {response.get('result', response)}")
        
        sock.close()
        return response
    
    # Start multiple scripts concurrently
    threads = []
    for i in range(5):
        thread = threading.Thread(target=execute_script, args=(i, i * 100))
        thread.start()
        threads.append(thread)
        time.sleep(0.1)  # Small delay to avoid overwhelming the daemon
    
    # Wait for all threads to complete
    for thread in threads:
        thread.join()
    
    print("✓ Concurrent script execution completed")

def test_script_timeout():
    """Test script execution timeout."""
    print("\nTesting script execution timeout...")
    
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect("/tmp/goxel.sock")
    
    # Script that would take too long (infinite loop)
    script_code = """
    // This script will timeout
    console.log("Starting infinite loop...");
    while (true) {
        // Infinite loop
    }
    """
    
    response = send_json_rpc_request(sock, "goxel.execute_script", {
        "script": script_code,
        "name": "timeout_test.js",
        "timeout_ms": 1000  # 1 second timeout
    })
    
    print(f"Response: {json.dumps(response, indent=2)}")
    
    # Should get a timeout error
    if "error" in response:
        print("✓ Script timeout handled correctly")
    else:
        print("✗ Script should have timed out")
    
    sock.close()

def test_script_from_file():
    """Test executing script from file."""
    print("\nTesting script execution from file...")
    
    # Create a test script file
    script_file = "/tmp/test_goxel_script.js"
    with open(script_file, "w") as f:
        f.write("""
        // Test script from file
        console.log("Executing from file: " + __filename);
        
        // Create a small cube
        for (var x = 0; x < 3; x++) {
            for (var y = 0; y < 3; y++) {
                for (var z = 0; z < 3; z++) {
                    goxel.addVoxel(x + 20, y + 20, z + 20, [0, 255, 0, 255]);
                }
            }
        }
        
        console.log("Created 3x3x3 green cube at (20, 20, 20)");
        """)
    
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect("/tmp/goxel.sock")
    
    response = send_json_rpc_request(sock, "goxel.execute_script", {
        "path": script_file,
        "timeout_ms": 5000
    })
    
    print(f"Response: {json.dumps(response, indent=2)}")
    
    if "result" in response and response["result"]["success"]:
        print("✓ Script from file executed successfully")
    else:
        print("✗ Script from file execution failed")
    
    sock.close()

def main():
    """Run all tests."""
    print("=== Goxel Daemon Script Execution Tests ===\n")
    
    try:
        # Ensure daemon is running
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect("/tmp/goxel.sock")
        sock.close()
    except Exception as e:
        print(f"Error: Cannot connect to Goxel daemon at /tmp/goxel.sock")
        print(f"Make sure the daemon is running: ./goxel-daemon --foreground --socket /tmp/goxel.sock")
        sys.exit(1)
    
    try:
        test_synchronous_execution()
        test_concurrent_execution()
        test_script_timeout()
        test_script_from_file()
        
        print("\n=== All tests completed ===")
    except Exception as e:
        print(f"\nTest failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()