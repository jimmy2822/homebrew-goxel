#!/usr/bin/env python3
"""Simple daemon rendering test"""

import json
import socket
import subprocess
import time
import os

SOCKET_PATH = "/tmp/goxel_simple_test.sock"
OUTPUT_PNG = "/tmp/goxel_simple_test.png"
DAEMON_PATH = "./goxel-daemon"

def cleanup():
    """Clean up test files"""
    for f in [SOCKET_PATH, OUTPUT_PNG]:
        if os.path.exists(f):
            os.remove(f)

def send_request(sock, request):
    """Send JSON-RPC request and get response"""
    sock.send(json.dumps(request).encode() + b"\n")
    response = sock.recv(4096)
    return json.loads(response)

def main():
    cleanup()
    
    print("=== Simple Daemon Rendering Test ===")
    
    # Start daemon
    print("Starting daemon...")
    daemon = subprocess.Popen([DAEMON_PATH, "--foreground", "--socket", SOCKET_PATH])
    time.sleep(1)
    
    try:
        # Create project
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.create_project",
            "params": ["SimpleTest", 32, 32, 32],
            "id": 1
        }
        response = send_request(sock, request)
        print(f"Create: {response.get('result', response)}")
        sock.close()
        
        # Add a few voxels
        colors = [
            (16, 16, 16, 255, 0, 0, 255),    # Red
            (15, 16, 16, 0, 255, 0, 255),    # Green
            (17, 16, 16, 0, 0, 255, 255),    # Blue
            (16, 15, 16, 255, 255, 0, 255),  # Yellow
            (16, 17, 16, 255, 0, 255, 255),  # Magenta
        ]
        
        for i, (x, y, z, r, g, b, a) in enumerate(colors):
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect(SOCKET_PATH)
            
            request = {
                "jsonrpc": "2.0",
                "method": "goxel.add_voxel",
                "params": [x, y, z, r, g, b, a],
                "id": i + 2
            }
            response = send_request(sock, request)
            print(f"Voxel {i+1}: {response.get('result', {}).get('success', False)}")
            sock.close()
        
        # Render
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.render_scene",
            "params": [OUTPUT_PNG, 400, 400],
            "id": 99
        }
        response = send_request(sock, request)
        print(f"Render: {response}")
        sock.close()
        
        # Check output
        time.sleep(0.5)
        if os.path.exists(OUTPUT_PNG):
            size = os.path.getsize(OUTPUT_PNG)
            print(f"\n✅ Image created: {OUTPUT_PNG} ({size} bytes)")
            subprocess.run(["open", OUTPUT_PNG], capture_output=True)
        else:
            print("\n❌ No image created")
            
    except Exception as e:
        print(f"Error: {e}")
    finally:
        daemon.terminate()
        daemon.wait()
        cleanup()

if __name__ == "__main__":
    main()