#!/usr/bin/env python3
"""Test daemon rendering and check visual output"""

import json
import socket
import subprocess
import time
import os
import sys

SOCKET_PATH = "/tmp/goxel_visual_test.sock"
OUTPUT_PNG = "/tmp/goxel_visual_test.png"
DAEMON_PATH = "./goxel-daemon"

def send_request(sock, request):
    """Send JSON-RPC request and get response"""
    sock.send(json.dumps(request).encode() + b"\n")
    response = sock.recv(4096)
    return json.loads(response)

def main():
    # Clean up
    if os.path.exists(SOCKET_PATH):
        os.remove(SOCKET_PATH)
    if os.path.exists(OUTPUT_PNG):
        os.remove(OUTPUT_PNG)
    
    print("=== Testing Daemon Rendering with Visual Output ===")
    
    # Start daemon
    print("Starting daemon...")
    daemon = subprocess.Popen([DAEMON_PATH, "--foreground", "--socket", SOCKET_PATH],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    time.sleep(1)
    
    try:
        # Create project
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.create_project",
            "params": ["RenderTest", 64, 64, 64],
            "id": 1
        }
        response = send_request(sock, request)
        print(f"Create project: {response}")
        sock.close()
        
        # Add colorful voxels in a 3D pattern
        print("Adding voxels in a 3D pattern...")
        voxel_id = 100
        
        # Create a cube of voxels
        for x in range(28, 37):  # 9x9x9 cube
            for y in range(28, 37):
                for z in range(28, 37):
                    # Color based on position
                    r = int((x - 28) * 28)
                    g = int((y - 28) * 28)
                    b = int((z - 28) * 28)
                    
                    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                    sock.connect(SOCKET_PATH)
                    
                    request = {
                        "jsonrpc": "2.0",
                        "method": "goxel.add_voxel",
                        "params": [x, y, z, r, g, b, 255],
                        "id": voxel_id
                    }
                    response = send_request(sock, request)
                    sock.close()
                    voxel_id += 1
        
        print(f"Added {voxel_id - 100} voxels")
        
        # Render scene
        print("Rendering scene...")
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.render_scene",
            "params": [OUTPUT_PNG, 800, 600],
            "id": 9999
        }
        response = send_request(sock, request)
        print(f"Render response: {response}")
        sock.close()
        
        # Check result
        time.sleep(0.5)
        if os.path.exists(OUTPUT_PNG):
            size = os.path.getsize(OUTPUT_PNG)
            print(f"✅ Rendered image created: {OUTPUT_PNG} ({size} bytes)")
            
            # Try to open the image
            if sys.platform == "darwin":
                subprocess.run(["open", OUTPUT_PNG])
            elif sys.platform.startswith("linux"):
                subprocess.run(["xdg-open", OUTPUT_PNG])
            
            print("\nImage opened for visual inspection.")
            print("Expected: Dark gray background with colorful voxels visible")
        else:
            print("❌ No rendered image found!")
            
    finally:
        # Stop daemon
        daemon.terminate()
        daemon.wait()
        
        # Clean up socket
        if os.path.exists(SOCKET_PATH):
            os.remove(SOCKET_PATH)

if __name__ == "__main__":
    main()