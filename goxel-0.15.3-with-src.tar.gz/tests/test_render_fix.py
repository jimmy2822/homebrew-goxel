#!/usr/bin/env python3
"""Test daemon rendering with dark background fix"""

import json
import socket
import time
import subprocess
import os
import signal

SOCKET_PATH = "/tmp/goxel_render_test.sock"
DAEMON_PATH = "./goxel-daemon"
OUTPUT_PATH = "/tmp/test_render_fix.png"

def cleanup():
    """Clean up test files"""
    if os.path.exists(SOCKET_PATH):
        os.remove(SOCKET_PATH)
    if os.path.exists(OUTPUT_PATH):
        os.remove(OUTPUT_PATH)

def send_request(sock, request):
    """Send JSON-RPC request and get response"""
    sock.send(json.dumps(request).encode() + b"\n")
    response = sock.recv(4096)
    return json.loads(response)

def main():
    cleanup()
    
    # Start daemon
    print("Starting daemon...")
    daemon = subprocess.Popen([DAEMON_PATH, "--foreground", "--socket", SOCKET_PATH])
    time.sleep(1)  # Wait for daemon to start
    
    try:
        # Create project
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.create_project",
            "params": ["TestRender", 32, 32, 32],
            "id": 1
        }
        response = send_request(sock, request)
        print(f"Create project: {response}")
        sock.close()
        
        # Add some colorful voxels
        colors = [
            (16, 16, 16, 255, 0, 0, 255),    # Red
            (17, 16, 16, 0, 255, 0, 255),    # Green
            (18, 16, 16, 0, 0, 255, 255),    # Blue
            (16, 17, 16, 255, 255, 0, 255),  # Yellow
            (16, 18, 16, 255, 0, 255, 255),  # Magenta
            (16, 16, 17, 0, 255, 255, 255),  # Cyan
        ]
        
        for i, color in enumerate(colors):
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect(SOCKET_PATH)
            
            request = {
                "jsonrpc": "2.0",
                "method": "goxel.add_voxel",
                "params": list(color),
                "id": i + 2
            }
            response = send_request(sock, request)
            print(f"Add voxel {i+1}: {response}")
            sock.close()
        
        # Render scene
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.render_scene",
            "params": [OUTPUT_PATH, 400, 400],
            "id": 10
        }
        response = send_request(sock, request)
        print(f"Render scene: {response}")
        sock.close()
        
        # Check if file was created
        if os.path.exists(OUTPUT_PATH):
            file_size = os.path.getsize(OUTPUT_PATH)
            print(f"✅ Rendered image created: {OUTPUT_PATH} ({file_size} bytes)")
            print("You can view the image to check if voxels are visible on dark background")
        else:
            print("❌ Failed to create rendered image")
            
    finally:
        # Stop daemon
        daemon.terminate()
        daemon.wait()
        cleanup()

if __name__ == "__main__":
    main()