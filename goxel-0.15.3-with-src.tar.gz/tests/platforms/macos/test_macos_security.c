/**
 * macOS security tests for Goxel v14.0 daemon.
 * Tests file permissions, sandboxing, and security features.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <Security/Security.h>
#include <sandbox.h>

#define TEST_SOCKET_PATH "/tmp/goxel_security_test.sock"
#define TEST_FILE_PATH "/tmp/goxel_security_test.dat"

// Test result tracking
typedef struct {
    int total;
    int passed;
    int failed;
    char last_error[256];
} test_results_t;

static test_results_t results = {0, 0, 0, ""};

// Test macros
#define RUN_TEST(name) do { \
    printf("Running %s...\n", #name); \
    results.total++; \
    if (name()) { \
        printf("  ✓ PASSED\n"); \
        results.passed++; \
    } else { \
        printf("  ✗ FAILED: %s\n", results.last_error); \
        results.failed++; \
    } \
} while(0)

#define TEST_ASSERT(cond, msg) do { \
    if (!(cond)) { \
        snprintf(results.last_error, sizeof(results.last_error), "%s", msg); \
        return 0; \
    } \
} while(0)

// Test 1: File permissions security
static int test_file_permissions_security(void) {
    // Create test file with restrictive permissions
    int fd = open(TEST_FILE_PATH, O_CREAT | O_WRONLY | O_EXCL, 0600);
    TEST_ASSERT(fd >= 0, "Failed to create test file");
    
    write(fd, "sensitive data\n", 15);
    close(fd);
    
    // Verify permissions
    struct stat st;
    TEST_ASSERT(stat(TEST_FILE_PATH, &st) == 0, "stat failed");
    
    mode_t perms = st.st_mode & 0777;
    TEST_ASSERT(perms == 0600, "File permissions not restrictive enough");
    
    // Verify owner
    TEST_ASSERT(st.st_uid == getuid(), "File not owned by current user");
    
    // Try to make it world-readable (should succeed but we'll change it back)
    TEST_ASSERT(chmod(TEST_FILE_PATH, 0644) == 0, "chmod failed");
    
    // Restore secure permissions
    TEST_ASSERT(chmod(TEST_FILE_PATH, 0600) == 0, "chmod restore failed");
    
    unlink(TEST_FILE_PATH);
    return 1;
}

// Test 2: Socket permissions security
static int test_socket_permissions_security(void) {
    unlink(TEST_SOCKET_PATH);
    
    // Create socket
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TEST_SOCKET_PATH, sizeof(addr.sun_path) - 1);
    
    TEST_ASSERT(bind(fd, (struct sockaddr*)&addr, sizeof(addr)) == 0, "Bind failed");
    
    // Set secure permissions (user + group only)
    mode_t secure_mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP;
    TEST_ASSERT(chmod(TEST_SOCKET_PATH, secure_mode) == 0, "chmod failed");
    
    // Verify permissions
    struct stat st;
    TEST_ASSERT(stat(TEST_SOCKET_PATH, &st) == 0, "stat failed");
    TEST_ASSERT((st.st_mode & 0777) == secure_mode, "Socket permissions not secure");
    
    // Verify no world access
    TEST_ASSERT((st.st_mode & S_IROTH) == 0, "Socket readable by others");
    TEST_ASSERT((st.st_mode & S_IWOTH) == 0, "Socket writable by others");
    
    close(fd);
    unlink(TEST_SOCKET_PATH);
    return 1;
}

// Test 3: Process ownership
static int test_process_ownership(void) {
    uid_t uid = getuid();
    gid_t gid = getgid();
    uid_t euid = geteuid();
    gid_t egid = getegid();
    
    printf("    UID: %d, GID: %d\n", uid, gid);
    printf("    EUID: %d, EGID: %d\n", euid, egid);
    
    // Verify not running as root
    TEST_ASSERT(uid != 0, "Running as root (unsafe for testing)");
    TEST_ASSERT(euid != 0, "Effective UID is root (unsafe)");
    
    // Get user info
    struct passwd *pw = getpwuid(uid);
    TEST_ASSERT(pw != NULL, "Cannot get user info");
    printf("    User: %s\n", pw->pw_name);
    
    // Get group info
    struct group *gr = getgrgid(gid);
    TEST_ASSERT(gr != NULL, "Cannot get group info");
    printf("    Group: %s\n", gr->gr_name);
    
    return 1;
}

// Test 4: Sandbox detection
static int test_sandbox_detection(void) {
    // Check if we're sandboxed
    #ifdef __APPLE__
    char *error = NULL;
    int sandboxed = sandbox_check(getpid(), NULL, &error);
    
    if (sandboxed == 0) {
        printf("    Process is NOT sandboxed\n");
    } else if (sandboxed == 1) {
        printf("    Process IS sandboxed\n");
    } else {
        printf("    Cannot determine sandbox status: %s\n", error ? error : "unknown error");
    }
    
    if (error) {
        sandbox_free_error(error);
    }
    #else
    printf("    Sandbox detection not available on this platform\n");
    #endif
    
    // This test passes regardless of sandbox status
    // In production, daemon should NOT be sandboxed for socket access
    return 1;
}

// Test 5: Secure temporary files
static int test_secure_temp_files(void) {
    // Create secure temporary file
    char temp_template[] = "/tmp/goxel_secure_XXXXXX";
    int fd = mkstemp(temp_template);
    TEST_ASSERT(fd >= 0, "mkstemp failed");
    
    printf("    Created secure temp file: %s\n", temp_template);
    
    // Verify permissions (should be 0600 by default)
    struct stat st;
    TEST_ASSERT(fstat(fd, &st) == 0, "fstat failed");
    
    mode_t perms = st.st_mode & 0777;
    TEST_ASSERT(perms == 0600, "Temp file not created with secure permissions");
    
    // Write and read test
    const char *data = "secure test data\n";
    TEST_ASSERT(write(fd, data, strlen(data)) == (ssize_t)strlen(data), "Write failed");
    
    lseek(fd, 0, SEEK_SET);
    char buffer[256];
    ssize_t n = read(fd, buffer, sizeof(buffer) - 1);
    TEST_ASSERT(n > 0, "Read failed");
    buffer[n] = '\0';
    TEST_ASSERT(strcmp(buffer, data) == 0, "Data mismatch");
    
    close(fd);
    unlink(temp_template);
    return 1;
}

// Test 6: Directory traversal protection
static int test_directory_traversal(void) {
    // Test various path constructions
    const char *dangerous_paths[] = {
        "../../../etc/passwd",
        "/tmp/../etc/passwd",
        "/tmp/./../../etc/passwd",
        "~/../../../etc/passwd",
        NULL
    };
    
    for (int i = 0; dangerous_paths[i]; i++) {
        // In a real daemon, these should be rejected or sanitized
        char full_path[512];
        snprintf(full_path, sizeof(full_path), "/tmp/goxel/%s", dangerous_paths[i]);
        
        // Check if path escapes /tmp/goxel
        char resolved[512];
        if (realpath(full_path, resolved) != NULL) {
            // Path exists, check if it's outside our directory
            TEST_ASSERT(strncmp(resolved, "/tmp/goxel/", 11) == 0, 
                       "Path traversal not prevented");
        } else {
            // Path doesn't exist, which is fine for this test
            printf("    Path %d safely non-existent\n", i);
        }
    }
    
    return 1;
}

// Test 7: Input validation
static int test_input_validation(void) {
    // Test dangerous input strings
    const char *dangerous_inputs[] = {
        "'; DROP TABLE users; --",
        "../../../../etc/passwd",
        "%s%s%s%s%s%s%s%s",
        "\0\0\0\0",
        "A" /* multiplied by 10000 would be a long string */,
        NULL
    };
    
    for (int i = 0; dangerous_inputs[i]; i++) {
        // Simulate validation (in real code, these would be sanitized)
        size_t len = strlen(dangerous_inputs[i]);
        TEST_ASSERT(len < 1024, "Input too long");
        
        // Check for null bytes (except the null test)
        if (i != 3) {
            for (size_t j = 0; j < len; j++) {
                TEST_ASSERT(dangerous_inputs[i][j] != '\0', "Embedded null byte");
            }
        }
    }
    
    printf("    Input validation tests passed\n");
    return 1;
}

// Test 8: Resource limits
static int test_resource_limits(void) {
    struct rlimit rlim;
    
    // Check file descriptor limit
    TEST_ASSERT(getrlimit(RLIMIT_NOFILE, &rlim) == 0, "getrlimit NOFILE failed");
    printf("    File descriptors: %llu (soft), %llu (hard)\n",
           (unsigned long long)rlim.rlim_cur, (unsigned long long)rlim.rlim_max);
    
    // Check memory limit
    TEST_ASSERT(getrlimit(RLIMIT_AS, &rlim) == 0, "getrlimit AS failed");
    if (rlim.rlim_cur == RLIM_INFINITY) {
        printf("    Virtual memory: unlimited\n");
    } else {
        printf("    Virtual memory: %llu MB (soft), %llu MB (hard)\n",
               (unsigned long long)(rlim.rlim_cur / 1024 / 1024),
               (unsigned long long)(rlim.rlim_max / 1024 / 1024));
    }
    
    // Check core dump limit
    TEST_ASSERT(getrlimit(RLIMIT_CORE, &rlim) == 0, "getrlimit CORE failed");
    printf("    Core dump size: %llu\n", (unsigned long long)rlim.rlim_cur);
    
    return 1;
}

int main(void) {
    printf("=== macOS Security Tests for Goxel v14.0 ===\n");
    printf("Platform: macOS\n");
    printf("Process: PID %d\n", getpid());
    printf("\n");
    
    // Run all tests
    RUN_TEST(test_file_permissions_security);
    RUN_TEST(test_socket_permissions_security);
    RUN_TEST(test_process_ownership);
    RUN_TEST(test_sandbox_detection);
    RUN_TEST(test_secure_temp_files);
    RUN_TEST(test_directory_traversal);
    RUN_TEST(test_input_validation);
    RUN_TEST(test_resource_limits);
    
    // Summary
    printf("\n=== Test Summary ===\n");
    printf("Total tests: %d\n", results.total);
    printf("Passed: %d\n", results.passed);
    printf("Failed: %d\n", results.failed);
    printf("Success rate: %.1f%%\n", 
           results.total > 0 ? (100.0 * results.passed / results.total) : 0);
    
    return results.failed > 0 ? 1 : 0;
}