/* Basic daemon functionality test for macOS */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <signal.h>
#include <time.h>

#define SOCKET_PATH "/tmp/goxel_basic_test.sock"
#define PID_FILE "/tmp/goxel_basic_test.pid"

int test_daemon_connection() {
    struct sockaddr_un addr;
    int client_fd;
    char request[] = "{\"jsonrpc\":\"2.0\",\"method\":\"ping\",\"id\":1}";
    char response[1024];
    
    // Create socket
    client_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (client_fd < 0) {
        perror("socket");
        return -1;
    }
    
    // Setup address
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path) - 1);
    
    // Connect
    if (connect(client_fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("connect");
        close(client_fd);
        return -1;
    }
    
    // Send request
    if (send(client_fd, request, strlen(request), 0) < 0) {
        perror("send");
        close(client_fd);
        return -1;
    }
    
    // Receive response
    ssize_t bytes = recv(client_fd, response, sizeof(response) - 1, 0);
    if (bytes > 0) {
        response[bytes] = '\0';
        printf("Response: %s\n", response);
    }
    
    close(client_fd);
    return (bytes > 0) ? 0 : -1;
}

int main() {
    printf("Starting basic daemon test...\n");
    
    // Start daemon in background
    pid_t pid = fork();
    if (pid == 0) {
        // Child process - run daemon
        execl("/Users/jimmy/jimmy_side_projects/goxel/tests/goxel-daemon",
              "goxel-daemon",
              "--foreground",
              "--socket", SOCKET_PATH,
              "--pid-file", PID_FILE,
              "--verbose",
              NULL);
        perror("execl");
        exit(1);
    }
    
    // Parent process - wait for daemon to start
    sleep(3);
    
    // Test connection
    printf("Testing daemon connection...\n");
    int result = test_daemon_connection();
    
    // Kill daemon
    kill(pid, SIGTERM);
    sleep(1);
    
    // Clean up
    unlink(SOCKET_PATH);
    unlink(PID_FILE);
    
    if (result == 0) {
        printf("Test PASSED\n");
        return 0;
    } else {
        printf("Test FAILED\n");
        return 1;
    }
}