#!/bin/bash
# Goxel v14.0 macOS Platform Testing Suite
# Testing on both Intel x86_64 and Apple Silicon ARM64

set -e

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GOXEL_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
DAEMON_BIN="$GOXEL_ROOT/tests/goxel-daemon"
RESULTS_DIR="$SCRIPT_DIR/../results"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
PLATFORM_ARCH=$(uname -m)
MACOS_VERSION=$(sw_vers -productVersion)

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Test results tracking
test_results=""
test_count=0
passed_count=0
failed_count=0

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

log_error() {
    echo -e "${RED}[FAIL]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Test framework
run_test() {
    local test_name=$1
    local test_function=$2
    test_count=$((test_count + 1))
    
    log_info "Running test: $test_name"
    if $test_function; then
        test_results="$test_results\n$test_name:PASSED"
        passed_count=$((passed_count + 1))
        log_success "$test_name"
    else
        test_results="$test_results\n$test_name:FAILED"
        failed_count=$((failed_count + 1))
        log_error "$test_name"
    fi
}

# Platform information gathering
gather_platform_info() {
    cat > "$RESULTS_DIR/macos_platform_info_$TIMESTAMP.json" << EOF
{
    "platform": {
        "os": "macOS",
        "version": "$MACOS_VERSION",
        "architecture": "$PLATFORM_ARCH",
        "kernel": "$(uname -r)",
        "hardware": "$(sysctl -n hw.model)",
        "cpu_cores": $(sysctl -n hw.ncpu),
        "memory_gb": $(echo "scale=2; $(sysctl -n hw.memsize) / 1024 / 1024 / 1024" | bc),
        "test_timestamp": "$TIMESTAMP"
    }
}
EOF
}

# Test: Daemon startup and initialization
test_daemon_startup() {
    local socket="/tmp/goxel_test_$$.sock"
    local pid_file="/tmp/goxel_test_$$.pid"
    
    # Clean up any existing files
    rm -f "$socket" "$pid_file"
    
    # Start daemon
    "$DAEMON_BIN" --daemonize --socket "$socket" --pid-file "$pid_file" &
    
    # Wait for startup (up to 5 seconds)
    local count=0
    while [[ ! -S "$socket" ]] && [[ $count -lt 50 ]]; do
        sleep 0.1
        count=$((count + 1))
    done
    
    # Read PID from file
    if [[ -f "$pid_file" ]]; then
        local daemon_pid=$(cat "$pid_file")
        
        # Check if daemon is running
        if kill -0 $daemon_pid 2>/dev/null; then
            # Check socket exists
            if [[ -S "$socket" ]]; then
                # Clean shutdown
                kill $daemon_pid 2>/dev/null
                wait $daemon_pid 2>/dev/null
                rm -f "$socket" "$pid_file"
                return 0
            fi
        fi
    fi
    
    # Cleanup on failure
    pkill -f "goxel-daemon.*$socket" 2>/dev/null || true
    rm -f "$socket" "$pid_file"
    return 1
}

# Test: Socket permissions
test_socket_permissions() {
    local socket="/tmp/goxel_perm_test_$$.sock"
    local pid_file="/tmp/goxel_perm_test_$$.pid"
    
    # Start daemon
    "$DAEMON_BIN" --daemonize --socket "$socket" --pid-file "$pid_file" &
    local daemon_pid=$!
    sleep 1
    
    # Check socket permissions (should be 0660 or similar)
    local perms=$(stat -f "%Lp" "$socket" 2>/dev/null)
    
    # Clean up
    kill $daemon_pid 2>/dev/null
    wait $daemon_pid 2>/dev/null
    rm -f "$socket" "$pid_file"
    
    # macOS might have different default permissions
    if [[ "$perms" == "755" ]] || [[ "$perms" == "660" ]] || [[ "$perms" == "600" ]]; then
        return 0
    else
        log_error "Unexpected socket permissions: $perms"
        return 1
    fi
}

# Test: Signal handling
test_signal_handling() {
    local socket="/tmp/goxel_sig_test_$$.sock"
    local pid_file="/tmp/goxel_sig_test_$$.pid"
    
    # Start daemon
    "$DAEMON_BIN" --daemonize --socket "$socket" --pid-file "$pid_file" &
    local daemon_pid=$!
    sleep 1
    
    # Test SIGTERM handling
    kill -TERM $daemon_pid
    
    # Wait for graceful shutdown (up to 5 seconds)
    local count=0
    while kill -0 $daemon_pid 2>/dev/null && [[ $count -lt 50 ]]; do
        sleep 0.1
        count=$((count + 1))
    done
    
    # Check if daemon shut down properly
    if ! kill -0 $daemon_pid 2>/dev/null; then
        # Check if socket was cleaned up
        if [[ ! -S "$socket" ]]; then
            rm -f "$pid_file"
            return 0
        fi
    fi
    
    # Force kill if still running
    kill -9 $daemon_pid 2>/dev/null || true
    rm -f "$socket" "$pid_file"
    return 1
}

# Test: Multiple client connections
test_multiple_clients() {
    local socket="/tmp/goxel_multi_test_$$.sock"
    local pid_file="/tmp/goxel_multi_test_$$.pid"
    
    # Start daemon
    "$DAEMON_BIN" --daemonize --socket "$socket" --pid-file "$pid_file" &
    local daemon_pid=$!
    sleep 1
    
    # Try to connect multiple clients simultaneously
    local success=true
    for i in {1..5}; do
        (echo '{"jsonrpc":"2.0","method":"ping","id":'$i'}' | nc -U "$socket") &
    done
    
    # Wait for all connections
    wait
    
    # Clean up
    kill $daemon_pid 2>/dev/null
    wait $daemon_pid 2>/dev/null
    rm -f "$socket" "$pid_file"
    
    return 0
}

# Test: LaunchDaemon compatibility (macOS specific)
test_launchd_compatibility() {
    # Check if launchd plist can be validated
    local plist_path="$GOXEL_ROOT/scripts/com.goxel.daemon.plist"
    
    if [[ -f "$plist_path" ]]; then
        if plutil -lint "$plist_path" >/dev/null 2>&1; then
            log_info "LaunchDaemon plist is valid"
            return 0
        else
            log_error "LaunchDaemon plist validation failed"
            return 1
        fi
    else
        log_warning "LaunchDaemon plist not found, skipping"
        return 0
    fi
}

# Test: Universal binary support check
test_universal_binary() {
    # Check if daemon supports multiple architectures
    local file_info=$(file "$DAEMON_BIN" 2>/dev/null)
    
    log_info "Binary info: $file_info"
    
    # On Apple Silicon, it should at least support arm64
    if [[ "$PLATFORM_ARCH" == "arm64" ]]; then
        if [[ "$file_info" == *"arm64"* ]] || [[ "$file_info" == *"ARM64"* ]]; then
            return 0
        else
            log_error "Binary doesn't support ARM64"
            return 1
        fi
    fi
    
    # On Intel, it should support x86_64
    if [[ "$PLATFORM_ARCH" == "x86_64" ]]; then
        if [[ "$file_info" == *"x86_64"* ]]; then
            return 0
        else
            log_error "Binary doesn't support x86_64"
            return 1
        fi
    fi
    
    return 0
}

# Test: Performance benchmark
test_performance_benchmark() {
    local socket="/tmp/goxel_perf_test_$$.sock"
    local pid_file="/tmp/goxel_perf_test_$$.pid"
    
    # Start daemon
    "$DAEMON_BIN" --daemonize --socket "$socket" --pid-file "$pid_file" &
    local daemon_pid=$!
    sleep 1
    
    # Run simple performance test
    local start_time=$(date +%s.%N)
    
    for i in {1..100}; do
        echo '{"jsonrpc":"2.0","method":"ping","id":'$i'}' | nc -U "$socket" >/dev/null 2>&1
    done
    
    local end_time=$(date +%s.%N)
    local duration=$(echo "$end_time - $start_time" | bc)
    local avg_time=$(echo "scale=3; $duration / 100 * 1000" | bc)
    
    log_info "Average request time: ${avg_time}ms"
    
    # Clean up
    kill $daemon_pid 2>/dev/null
    wait $daemon_pid 2>/dev/null
    rm -f "$socket" "$pid_file"
    
    # Check if meets performance target (<2.1ms)
    if (( $(echo "$avg_time < 2.1" | bc -l) )); then
        return 0
    else
        log_error "Performance target not met: ${avg_time}ms > 2.1ms"
        return 1
    fi
}

# Test: Memory usage
test_memory_usage() {
    local socket="/tmp/goxel_mem_test_$$.sock"
    local pid_file="/tmp/goxel_mem_test_$$.pid"
    
    # Start daemon
    "$DAEMON_BIN" --daemonize --socket "$socket" --pid-file "$pid_file" &
    local daemon_pid=$!
    sleep 2
    
    # Get memory usage
    local mem_kb=$(ps -o rss= -p $daemon_pid | xargs)
    local mem_usage=$(echo "scale=2; $mem_kb / 1024" | bc)
    log_info "Memory usage: ${mem_usage}MB"
    
    # Clean up
    kill $daemon_pid 2>/dev/null
    wait $daemon_pid 2>/dev/null
    rm -f "$socket" "$pid_file"
    
    # Check if under 50MB baseline
    if (( $(echo "$mem_usage < 50" | bc -l) )); then
        return 0
    else
        log_error "Memory usage exceeds baseline: ${mem_usage}MB > 50MB"
        return 1
    fi
}

# Generate test report
generate_report() {
    local report_file="$RESULTS_DIR/macos_test_report_$TIMESTAMP.md"
    
    cat > "$report_file" << EOF
# macOS Platform Test Report
**Date**: $(date)
**Platform**: macOS $MACOS_VERSION ($PLATFORM_ARCH)
**Daemon Version**: v14.0.0

## Test Summary
- **Total Tests**: $test_count
- **Passed**: $passed_count
- **Failed**: $failed_count
- **Success Rate**: $(echo "scale=1; $passed_count * 100 / $test_count" | bc)%

## Test Results
EOF
    
    echo -e "$test_results" | grep -v '^$' | while IFS=: read -r test_name status; do
        if [[ "$status" == "PASSED" ]]; then
            echo "- ✅ $test_name" >> "$report_file"
        else
            echo "- ❌ $test_name" >> "$report_file"
        fi
    done
    
    cat >> "$report_file" << EOF

## Platform-Specific Notes
- Architecture: $PLATFORM_ARCH
- macOS Version: $MACOS_VERSION
- Universal Binary Support: $(if lipo -info "$DAEMON_BIN" 2>/dev/null | grep -q "arm64\|x86_64"; then echo "Yes"; else echo "No"; fi)

## Performance Metrics
See performance test results for detailed latency measurements.

## Recommendations
EOF
    
    if [[ $failed_count -gt 0 ]]; then
        echo "- ⚠️ Some tests failed. Review individual test results for details." >> "$report_file"
    else
        echo "- ✅ All tests passed. Platform is fully supported." >> "$report_file"
    fi
}

# Main execution
main() {
    echo "🧪 Goxel v14.0 macOS Platform Testing"
    echo "====================================="
    echo "Platform: macOS $MACOS_VERSION ($PLATFORM_ARCH)"
    echo ""
    
    # Create results directory
    mkdir -p "$RESULTS_DIR"
    
    # Gather platform information
    gather_platform_info
    
    # Run all tests
    run_test "Daemon Startup" test_daemon_startup
    run_test "Socket Permissions" test_socket_permissions
    run_test "Signal Handling" test_signal_handling
    run_test "Multiple Clients" test_multiple_clients
    run_test "LaunchDaemon Compatibility" test_launchd_compatibility
    run_test "Universal Binary" test_universal_binary
    run_test "Performance Benchmark" test_performance_benchmark
    run_test "Memory Usage" test_memory_usage
    
    # Generate report
    generate_report
    
    echo ""
    echo "Test Summary:"
    echo "============="
    echo "Total: $test_count | Passed: $passed_count | Failed: $failed_count"
    echo ""
    
    if [[ $failed_count -eq 0 ]]; then
        log_success "All macOS platform tests passed!"
        exit 0
    else
        log_error "Some tests failed. See report for details."
        exit 1
    fi
}

# Run tests
main