/**
 * Linux-specific Unix domain socket tests for Goxel v14.0 daemon.
 * Tests socket creation, permissions, and Linux-specific features.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <assert.h>
#include <time.h>
#include <pthread.h>
#include <linux/limits.h>

#define TEST_SOCKET_PATH "/tmp/goxel_test_linux.sock"
#define ABSTRACT_SOCKET "\0goxel_test_abstract"

// Test result tracking
typedef struct {
    int total;
    int passed;
    int failed;
    char last_error[256];
} test_results_t;

static test_results_t results = {0, 0, 0, ""};

// Test macros
#define RUN_TEST(name) do { \
    printf("Running %s...\n", #name); \
    results.total++; \
    if (name()) { \
        printf("  ✓ PASSED\n"); \
        results.passed++; \
    } else { \
        printf("  ✗ FAILED: %s\n", results.last_error); \
        results.failed++; \
    } \
} while(0)

#define TEST_ASSERT(cond, msg) do { \
    if (!(cond)) { \
        snprintf(results.last_error, sizeof(results.last_error), "%s", msg); \
        return 0; \
    } \
} while(0)

// Get time in nanoseconds
static uint64_t get_time_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
}

// Test 1: Basic socket creation
static int test_socket_creation(void) {
    unlink(TEST_SOCKET_PATH);
    
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TEST_SOCKET_PATH, sizeof(addr.sun_path) - 1);
    
    int ret = bind(fd, (struct sockaddr*)&addr, sizeof(addr));
    TEST_ASSERT(ret == 0, "Failed to bind socket");
    
    struct stat st;
    TEST_ASSERT(stat(TEST_SOCKET_PATH, &st) == 0, "Socket file not created");
    TEST_ASSERT(S_ISSOCK(st.st_mode), "File is not a socket");
    
    close(fd);
    unlink(TEST_SOCKET_PATH);
    return 1;
}

// Test 2: Abstract namespace sockets (Linux-specific)
static int test_abstract_namespace(void) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    memcpy(addr.sun_path, ABSTRACT_SOCKET, sizeof(ABSTRACT_SOCKET));
    
    // Abstract sockets use exact length, including null byte
    socklen_t len = offsetof(struct sockaddr_un, sun_path) + sizeof(ABSTRACT_SOCKET) - 1;
    
    int ret = bind(fd, (struct sockaddr*)&addr, len);
    TEST_ASSERT(ret == 0, "Failed to bind abstract socket");
    
    // Abstract sockets don't create filesystem entries
    struct stat st;
    TEST_ASSERT(stat(ABSTRACT_SOCKET + 1, &st) == -1, "Abstract socket created file");
    
    // Test listening
    TEST_ASSERT(listen(fd, 5) == 0, "Failed to listen on abstract socket");
    
    // Test connecting
    int client_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(client_fd >= 0, "Failed to create client socket");
    
    ret = connect(client_fd, (struct sockaddr*)&addr, len);
    TEST_ASSERT(ret == 0, "Failed to connect to abstract socket");
    
    close(client_fd);
    close(fd);
    
    printf("    Abstract namespace sockets working correctly\n");
    return 1;
}

// Test 3: SO_PEERCRED (Linux-specific)
static int test_peer_credentials(void) {
    unlink(TEST_SOCKET_PATH);
    
    // Create server socket
    int server_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(server_fd >= 0, "Failed to create server socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TEST_SOCKET_PATH, sizeof(addr.sun_path) - 1);
    
    TEST_ASSERT(bind(server_fd, (struct sockaddr*)&addr, sizeof(addr)) == 0, "Bind failed");
    TEST_ASSERT(listen(server_fd, 1) == 0, "Listen failed");
    
    // Create client connection
    int client_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(client_fd >= 0, "Failed to create client socket");
    
    // Fork to test in separate process
    pid_t pid = fork();
    if (pid == 0) {
        // Child: connect as client
        close(server_fd);
        connect(client_fd, (struct sockaddr*)&addr, sizeof(addr));
        pause(); // Wait for parent
        exit(0);
    } else if (pid > 0) {
        // Parent: accept and check credentials
        close(client_fd);
        
        int conn_fd = accept(server_fd, NULL, NULL);
        TEST_ASSERT(conn_fd >= 0, "Accept failed");
        
        struct ucred cred;
        socklen_t len = sizeof(cred);
        int ret = getsockopt(conn_fd, SOL_SOCKET, SO_PEERCRED, &cred, &len);
        TEST_ASSERT(ret == 0, "getsockopt SO_PEERCRED failed");
        
        printf("    Peer credentials: PID=%d, UID=%d, GID=%d\n", 
               cred.pid, cred.uid, cred.gid);
        
        TEST_ASSERT(cred.pid == pid, "Wrong peer PID");
        TEST_ASSERT(cred.uid == getuid(), "Wrong peer UID");
        TEST_ASSERT(cred.gid == getgid(), "Wrong peer GID");
        
        close(conn_fd);
        kill(pid, SIGTERM);
        waitpid(pid, NULL, 0);
    } else {
        TEST_ASSERT(0, "Fork failed");
    }
    
    close(server_fd);
    unlink(TEST_SOCKET_PATH);
    return 1;
}

// Test 4: Socket buffer sizes (Linux allows tuning)
static int test_socket_buffer_sizes(void) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    // Get default buffer sizes
    int sndbuf, rcvbuf;
    socklen_t len = sizeof(sndbuf);
    
    TEST_ASSERT(getsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, &len) == 0, 
                "Failed to get send buffer size");
    TEST_ASSERT(getsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcvbuf, &len) == 0,
                "Failed to get receive buffer size");
    
    printf("    Default buffers: send=%d, receive=%d\n", sndbuf, rcvbuf);
    
    // Try to increase buffer sizes
    int new_size = 1024 * 1024; // 1MB
    TEST_ASSERT(setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &new_size, sizeof(new_size)) == 0,
                "Failed to set send buffer size");
    TEST_ASSERT(setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &new_size, sizeof(new_size)) == 0,
                "Failed to set receive buffer size");
    
    // Verify new sizes (Linux may double the requested size)
    TEST_ASSERT(getsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, &len) == 0,
                "Failed to get new send buffer size");
    TEST_ASSERT(getsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcvbuf, &len) == 0,
                "Failed to get new receive buffer size");
    
    printf("    New buffers: send=%d, receive=%d\n", sndbuf, rcvbuf);
    TEST_ASSERT(sndbuf >= new_size, "Send buffer not increased");
    TEST_ASSERT(rcvbuf >= new_size, "Receive buffer not increased");
    
    close(fd);
    return 1;
}

// Test 5: Performance with epoll (Linux-specific)
static int test_epoll_performance(void) {
    #ifdef __linux__
    #include <sys/epoll.h>
    
    unlink(TEST_SOCKET_PATH);
    
    // Create server socket
    int server_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(server_fd >= 0, "Failed to create server socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TEST_SOCKET_PATH, sizeof(addr.sun_path) - 1);
    
    TEST_ASSERT(bind(server_fd, (struct sockaddr*)&addr, sizeof(addr)) == 0, "Bind failed");
    TEST_ASSERT(listen(server_fd, 128) == 0, "Listen failed");
    
    // Create epoll instance
    int epoll_fd = epoll_create1(0);
    TEST_ASSERT(epoll_fd >= 0, "epoll_create1 failed");
    
    // Add server socket to epoll
    struct epoll_event ev;
    ev.events = EPOLLIN;
    ev.data.fd = server_fd;
    TEST_ASSERT(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, server_fd, &ev) == 0,
                "epoll_ctl ADD failed");
    
    // Test epoll_wait performance
    uint64_t start = get_time_ns();
    
    struct epoll_event events[10];
    int n = epoll_wait(epoll_fd, events, 10, 0); // Non-blocking
    
    uint64_t end = get_time_ns();
    double elapsed_us = (end - start) / 1000.0;
    
    printf("    epoll_wait latency: %.2f μs\n", elapsed_us);
    TEST_ASSERT(elapsed_us < 100.0, "epoll_wait too slow");
    
    close(epoll_fd);
    close(server_fd);
    unlink(TEST_SOCKET_PATH);
    
    #else
    printf("    epoll not available on this platform\n");
    #endif
    
    return 1;
}

// Test 6: Path length limits
static int test_path_length_limits(void) {
    // Linux allows longer paths than macOS
    char long_path[PATH_MAX];
    memset(long_path, 'a', sizeof(long_path));
    long_path[0] = '/';
    long_path[1] = 't';
    long_path[2] = 'm';
    long_path[3] = 'p';
    long_path[4] = '/';
    
    // Test at 108 bytes (typical limit)
    long_path[107] = '\0';
    
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, long_path, sizeof(addr.sun_path) - 1);
    
    int ret = bind(fd, (struct sockaddr*)&addr, sizeof(addr));
    if (ret == 0) {
        unlink(long_path);
        printf("    Successfully bound to 107-byte path\n");
    } else {
        printf("    Failed to bind to 107-byte path (expected on some systems)\n");
    }
    close(fd);
    
    return 1;
}

// Test 7: Socket timestamping (Linux-specific)
static int test_socket_timestamping(void) {
    #ifdef SO_TIMESTAMP
    int fd = socket(AF_UNIX, SOCK_DGRAM, 0); // Use datagram for simplicity
    TEST_ASSERT(fd >= 0, "Failed to create socket");
    
    // Enable timestamping
    int enable = 1;
    int ret = setsockopt(fd, SOL_SOCKET, SO_TIMESTAMP, &enable, sizeof(enable));
    if (ret == 0) {
        printf("    Socket timestamping enabled\n");
        
        // Verify it's enabled
        int val;
        socklen_t len = sizeof(val);
        TEST_ASSERT(getsockopt(fd, SOL_SOCKET, SO_TIMESTAMP, &val, &len) == 0,
                    "Failed to get SO_TIMESTAMP");
        TEST_ASSERT(val != 0, "SO_TIMESTAMP not enabled");
    } else {
        printf("    Socket timestamping not supported\n");
    }
    
    close(fd);
    #else
    printf("    SO_TIMESTAMP not defined\n");
    #endif
    
    return 1;
}

// Test 8: cgroup awareness
static int test_cgroup_awareness(void) {
    // Check if we're in a cgroup
    FILE *fp = fopen("/proc/self/cgroup", "r");
    if (fp) {
        char line[256];
        printf("    Process cgroups:\n");
        while (fgets(line, sizeof(line), fp)) {
            printf("      %s", line);
        }
        fclose(fp);
    } else {
        printf("    Cannot read /proc/self/cgroup\n");
    }
    
    // Check systemd cgroup if available
    char path[512];
    snprintf(path, sizeof(path), "/sys/fs/cgroup/systemd/user.slice/user-%d.slice", getuid());
    
    struct stat st;
    if (stat(path, &st) == 0 && S_ISDIR(st.st_mode)) {
        printf("    Running under systemd user slice\n");
    }
    
    return 1;
}

int main(void) {
    printf("=== Linux Unix Socket Tests for Goxel v14.0 ===\n");
    printf("Platform: Linux\n");
    printf("Process: PID %d\n", getpid());
    printf("\n");
    
    // Run all tests
    RUN_TEST(test_socket_creation);
    RUN_TEST(test_abstract_namespace);
    RUN_TEST(test_peer_credentials);
    RUN_TEST(test_socket_buffer_sizes);
    RUN_TEST(test_epoll_performance);
    RUN_TEST(test_path_length_limits);
    RUN_TEST(test_socket_timestamping);
    RUN_TEST(test_cgroup_awareness);
    
    // Summary
    printf("\n=== Test Summary ===\n");
    printf("Total tests: %d\n", results.total);
    printf("Passed: %d\n", results.passed);
    printf("Failed: %d\n", results.failed);
    printf("Success rate: %.1f%%\n", 
           results.total > 0 ? (100.0 * results.passed / results.total) : 0);
    
    return results.failed > 0 ? 1 : 0;
}