#!/usr/bin/env python3
"""
Integration test for goxel-daemon script execution functionality.
Tests the goxel.execute_script JSON-RPC method.
"""

import socket
import json
import sys
import os

# Default socket path
SOCKET_PATH = os.environ.get('GOXEL_SOCKET_PATH', '/tmp/goxel.sock')

def send_request(sock, request):
    """Send JSON-RPC request and receive response"""
    sock.send(json.dumps(request).encode() + b"\n")
    response = b""
    while True:
        chunk = sock.recv(4096)
        response += chunk
        if b"\n" in chunk:
            break
    return json.loads(response.decode().strip())

def test_script_execution():
    """Test script execution functionality"""
    # Connect to daemon
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        sock.connect(SOCKET_PATH)
    except Exception as e:
        print(f"ERROR: Cannot connect to daemon at {SOCKET_PATH}: {e}")
        return False
    
    success_count = 0
    test_count = 0
    
    # Test 1: Simple expression
    test_count += 1
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.execute_script",
        "params": {"script": "42"},
        "id": 1
    }
    response = send_request(sock, request)
    if response.get('result', {}).get('success'):
        print("✓ Test 1: Simple expression - PASSED")
        success_count += 1
    else:
        print("✗ Test 1: Simple expression - FAILED")
        print(f"  Response: {response}")
    
    # Test 2: Variable assignment
    test_count += 1
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.execute_script",
        "params": {"script": "var x = 10; var y = 20; x + y"},
        "id": 2
    }
    response = send_request(sock, request)
    if response.get('result', {}).get('success'):
        print("✓ Test 2: Variable assignment - PASSED")
        success_count += 1
    else:
        print("✗ Test 2: Variable assignment - FAILED")
        print(f"  Response: {response}")
    
    # Test 3: Console output
    test_count += 1
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.execute_script",
        "params": {"script": "console.log('Test'); 'ok'"},
        "id": 3
    }
    response = send_request(sock, request)
    if response.get('result', {}).get('success'):
        print("✓ Test 3: Console output - PASSED")
        success_count += 1
    else:
        print("✗ Test 3: Console output - FAILED")
        print(f"  Response: {response}")
    
    # Test 4: Error handling
    test_count += 1
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.execute_script",
        "params": {"script": "throw new Error('test')"},
        "id": 4
    }
    response = send_request(sock, request)
    if response.get('result', {}).get('success') == False:
        print("✓ Test 4: Error handling - PASSED")
        success_count += 1
    else:
        print("✗ Test 4: Error handling - FAILED")
        print(f"  Response: {response}")
    
    # Test 5: Script file execution
    test_count += 1
    test_script_path = "/tmp/goxel_test_script.js"
    with open(test_script_path, "w") as f:
        f.write("console.log('From file'); 123")
    
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.execute_script",
        "params": {"path": test_script_path},
        "id": 5
    }
    response = send_request(sock, request)
    if response.get('result', {}).get('success'):
        print("✓ Test 5: Script file execution - PASSED")
        success_count += 1
    else:
        print("✗ Test 5: Script file execution - FAILED")
        print(f"  Response: {response}")
    
    # Clean up
    os.unlink(test_script_path)
    sock.close()
    
    print(f"\nScript execution tests: {success_count}/{test_count} passed")
    return success_count == test_count

if __name__ == "__main__":
    success = test_script_execution()
    sys.exit(0 if success else 1)