#!/usr/bin/env python3
"""Test daemon rendering and keep output for inspection"""

import json
import socket
import subprocess
import time
import os

SOCKET_PATH = "/tmp/goxel_keep_test.sock"
OUTPUT_PNG = "/tmp/goxel_keep_test.png"
DAEMON_PATH = "./goxel-daemon"

def send_request(sock, request):
    """Send JSON-RPC request and get response"""
    sock.send(json.dumps(request).encode() + b"\n")
    response = sock.recv(4096)
    return json.loads(response)

def main():
    # Clean up socket only
    if os.path.exists(SOCKET_PATH):
        os.remove(SOCKET_PATH)
    
    print("=== Daemon Rendering Test (Keep Output) ===")
    
    # Start daemon
    print("Starting daemon...")
    daemon = subprocess.Popen([DAEMON_PATH, "--foreground", "--socket", SOCKET_PATH],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    time.sleep(1)
    
    try:
        # Create project
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.create_project",
            "params": ["KeepTest", 32, 32, 32],
            "id": 1
        }
        response = send_request(sock, request)
        print(f"Create: {response.get('result', {}).get('success', False)}")
        sock.close()
        
        # Add a simple cross pattern
        voxels = [
            # Horizontal line (red)
            (14, 16, 16, 255, 0, 0, 255),
            (15, 16, 16, 255, 0, 0, 255),
            (16, 16, 16, 255, 0, 0, 255),
            (17, 16, 16, 255, 0, 0, 255),
            (18, 16, 16, 255, 0, 0, 255),
            # Vertical line (green)
            (16, 14, 16, 0, 255, 0, 255),
            (16, 15, 16, 0, 255, 0, 255),
            # Center already added
            (16, 17, 16, 0, 255, 0, 255),
            (16, 18, 16, 0, 255, 0, 255),
            # Z-axis line (blue)
            (16, 16, 14, 0, 0, 255, 255),
            (16, 16, 15, 0, 0, 255, 255),
            # Center already added
            (16, 16, 17, 0, 0, 255, 255),
            (16, 16, 18, 0, 0, 255, 255),
        ]
        
        for i, (x, y, z, r, g, b, a) in enumerate(voxels):
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect(SOCKET_PATH)
            
            request = {
                "jsonrpc": "2.0",
                "method": "goxel.add_voxel",
                "params": [x, y, z, r, g, b, a],
                "id": i + 2
            }
            send_request(sock, request)
            sock.close()
        
        print(f"Added {len(voxels)} voxels in cross pattern")
        
        # Render
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.render_scene",
            "params": [OUTPUT_PNG, 400, 400],
            "id": 99
        }
        response = send_request(sock, request)
        print(f"Render: {response.get('result', {}).get('success', False)}")
        sock.close()
        
        # Check output
        time.sleep(0.5)
        if os.path.exists(OUTPUT_PNG):
            size = os.path.getsize(OUTPUT_PNG)
            print(f"\n✅ Image created: {OUTPUT_PNG} ({size} bytes)")
            print("Output file kept for inspection.")
            print("\nTo view: open /tmp/goxel_keep_test.png")
        else:
            print("\n❌ No image created")
            
    finally:
        daemon.terminate()
        daemon.wait()
        if os.path.exists(SOCKET_PATH):
            os.remove(SOCKET_PATH)

if __name__ == "__main__":
    main()