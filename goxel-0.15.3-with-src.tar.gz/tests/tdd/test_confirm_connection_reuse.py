#!/usr/bin/env python3
"""
Simple test to confirm connection reuse status
Tests only what should work without crashing
"""

import socket
import json
import sys

def test_multiple_creates():
    """Test multiple create_project calls on same connection"""
    
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        sock.connect("/tmp/goxel_test.sock")
    except:
        print("Error: Cannot connect. Start daemon with:")
        print("./goxel-daemon --foreground --socket /tmp/goxel_test.sock")
        return False
    
    print("Connected to daemon")
    
    # Test multiple create_project calls
    for i in range(3):
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.create_project",
            "params": [f"Test{i}", 16, 16, 16],
            "id": i + 1
        }
        
        print(f"\nSending request {i+1}...")
        sock.send(json.dumps(request).encode() + b"\n")
        
        # Read response with proper JSON framing
        response_bytes = b""
        brace_count = 0
        in_string = False
        escape_next = False
        
        while True:
            try:
                char = sock.recv(1)
                if not char:
                    print("Connection closed!")
                    return False
                    
                response_bytes += char
                c = char.decode('utf-8', errors='ignore')
                
                if not in_string and not escape_next:
                    if c == '{':
                        brace_count += 1
                    elif c == '}':
                        brace_count -= 1
                        if brace_count == 0:
                            break
                    elif c == '"':
                        in_string = True
                elif in_string and not escape_next:
                    if c == '\\':
                        escape_next = True
                    elif c == '"':
                        in_string = False
                else:
                    escape_next = False
            except socket.timeout:
                print("Timeout!")
                return False
        
        # Parse response
        try:
            response = json.loads(response_bytes.decode())
            print(f"Response {i+1}: {json.dumps(response, indent=2)}")
            
            if response.get("id") != i + 1:
                print(f"ERROR: Response ID mismatch!")
                return False
                
        except json.JSONDecodeError as e:
            print(f"ERROR: Failed to parse response: {e}")
            print(f"Raw: {response_bytes}")
            return False
    
    sock.close()
    
    print("\n" + "="*60)
    print("✅ SUCCESS: 3 requests completed on same connection!")
    print("Connection reuse is working for create_project!")
    return True

if __name__ == "__main__":
    success = test_multiple_creates()
    sys.exit(0 if success else 1)