#!/usr/bin/env python3
"""
Simple verification that connection reuse works in current daemon
"""

import socket
import json
import sys

def test_connection_reuse():
    """Verify daemon supports multiple requests on same connection"""
    
    # Start daemon manually first:
    # ./goxel-daemon --foreground --socket /tmp/goxel_test.sock
    
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        sock.connect("/tmp/goxel_test.sock")
    except:
        print("Error: Cannot connect. Start daemon with:")
        print("./goxel-daemon --foreground --socket /tmp/goxel_test.sock")
        return False
    
    print("Connected to daemon")
    
    # Test sequence that should work
    requests = [
        # 1. Create project first
        {
            "jsonrpc": "2.0",
            "method": "goxel.create_project",
            "params": ["TestProject", 32, 32, 32],
            "id": 1
        },
        # 2. List layers (should show default layer)
        {
            "jsonrpc": "2.0",
            "method": "goxel.list_layers",
            "params": [],
            "id": 2
        },
        # 3. Create new layer
        {
            "jsonrpc": "2.0",
            "method": "goxel.create_layer",
            "params": ["Layer2"],
            "id": 3
        },
        # 4. Add voxel
        {
            "jsonrpc": "2.0",
            "method": "goxel.add_voxels",
            "params": {
                "voxels": [{
                    "position": [10, 10, 10],
                    "color": [255, 0, 0, 255]
                }]
            },
            "id": 4
        },
        # 5. List layers again
        {
            "jsonrpc": "2.0",
            "method": "goxel.list_layers",
            "params": [],
            "id": 5
        }
    ]
    
    for req in requests:
        print(f"\n{'='*60}")
        print(f"Request {req['id']}: {req['method']}")
        print(f"Params: {req['params']}")
        
        # Send request
        sock.send(json.dumps(req).encode() + b"\n")
        
        # Receive response with proper JSON framing
        response_bytes = b""
        brace_count = 0
        in_string = False
        escape_next = False
        
        while True:
            char = sock.recv(1)
            if not char:
                print("Connection closed!")
                return False
                
            response_bytes += char
            c = char.decode('utf-8', errors='ignore')
            
            if not in_string and not escape_next:
                if c == '{':
                    brace_count += 1
                elif c == '}':
                    brace_count -= 1
                    if brace_count == 0:
                        break
                elif c == '"':
                    in_string = True
            elif in_string and not escape_next:
                if c == '\\':
                    escape_next = True
                elif c == '"':
                    in_string = False
            else:
                escape_next = False
        
        # Parse response
        try:
            response = json.loads(response_bytes.decode())
            print(f"Response: {json.dumps(response, indent=2)}")
            
            # Verify response ID matches request
            if response.get("id") != req["id"]:
                print(f"ERROR: Response ID mismatch! Expected {req['id']}, got {response.get('id')}")
                return False
                
        except json.JSONDecodeError as e:
            print(f"ERROR: Failed to parse response: {e}")
            print(f"Raw response: {response_bytes}")
            return False
    
    sock.close()
    
    print("\n" + "="*60)
    print("✅ SUCCESS: All 5 requests completed on same connection!")
    print("Connection reuse is working correctly!")
    return True

if __name__ == "__main__":
    success = test_connection_reuse()
    sys.exit(0 if success else 1)