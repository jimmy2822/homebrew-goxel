#!/usr/bin/env python3
"""
Simple test to verify connection reuse issue
"""

import socket
import json
import time
import sys

def test_connection_reuse():
    """Test if daemon supports multiple requests on same connection"""
    
    # Connect to daemon
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        sock.connect("/tmp/goxel_test.sock")
    except:
        print("Error: Cannot connect to daemon. Is it running?")
        print("Start with: brew services start goxel")
        return False
    
    print("Connected to daemon")
    
    # Test 1: Send first request
    request1 = {
        "jsonrpc": "2.0",
        "method": "goxel.create_project",
        "params": ["Test1", 16, 16, 16],
        "id": 1
    }
    
    print("\nSending request 1:", json.dumps(request1))
    sock.send(json.dumps(request1).encode() + b"\n")
    
    # Receive response 1
    response1 = sock.recv(4096)
    print("Response 1:", response1.decode())
    
    if not response1:
        print("ERROR: No response to first request")
        return False
    
    # Test 2: Send second request on SAME connection
    request2 = {
        "jsonrpc": "2.0",
        "method": "goxel.list_layers",
        "params": [],
        "id": 2
    }
    
    print("\nSending request 2 on same connection:", json.dumps(request2))
    sock.send(json.dumps(request2).encode() + b"\n")
    
    # Try to receive response 2
    sock.settimeout(2.0)  # 2 second timeout
    try:
        response2 = sock.recv(4096)
        print("Response 2:", response2.decode())
        
        if response2:
            print("\n✅ SUCCESS: Connection reuse works!")
            return True
        else:
            print("\n❌ FAIL: No response to second request")
            return False
            
    except socket.timeout:
        print("\n❌ FAIL: Timeout waiting for second response")
        print("This confirms the connection reuse issue")
        return False
    
    finally:
        sock.close()

if __name__ == "__main__":
    success = test_connection_reuse()
    sys.exit(0 if success else 1)