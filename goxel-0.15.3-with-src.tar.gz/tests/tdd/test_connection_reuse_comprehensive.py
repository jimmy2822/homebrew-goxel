#!/usr/bin/env python3
"""
Comprehensive test for connection reuse in Goxel daemon
"""

import socket
import json
import time
import sys
import threading

def send_request(sock, request):
    """Send a JSON-RPC request and return the response"""
    sock.send(json.dumps(request).encode() + b"\n")
    
    # Read response - need to handle JSON framing
    response = b""
    brace_count = 0
    in_string = False
    escape_next = False
    
    while True:
        char = sock.recv(1)
        if not char:
            break
            
        response += char
        c = char.decode('utf-8', errors='ignore')
        
        if not in_string and not escape_next:
            if c == '{':
                brace_count += 1
            elif c == '}':
                brace_count -= 1
                if brace_count == 0:
                    break
            elif c == '"':
                in_string = True
        elif in_string and not escape_next:
            if c == '\\':
                escape_next = True
            elif c == '"':
                in_string = False
        else:
            escape_next = False
    
    return json.loads(response.decode())

def test_basic_reuse():
    """Test basic connection reuse"""
    print("=== Test 1: Basic Connection Reuse ===")
    
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect("/tmp/goxel_test.sock")
    
    # Send 5 requests on same connection
    for i in range(1, 6):
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.create_layer",
            "params": [f"Layer{i}"],
            "id": i
        }
        
        print(f"\nRequest {i}: {request['method']}")
        response = send_request(sock, request)
        print(f"Response {i}: {response}")
        
        assert response.get("id") == i, f"Wrong response ID: expected {i}, got {response.get('id')}"
        
    sock.close()
    print("\n✅ Basic reuse test passed!")
    return True

def test_mixed_methods():
    """Test different methods on same connection"""
    print("\n=== Test 2: Mixed Methods ===")
    
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect("/tmp/goxel_test.sock")
    
    # Different methods
    methods = [
        ("goxel.create_project", ["MixedTest", 32, 32, 32]),
        ("goxel.list_layers", []),
        ("goxel.create_layer", ["TestLayer"]),
        ("goxel.add_voxels", {"voxels": [{"position": [10, 10, 10], "color": [255, 0, 0, 255]}]}),
        ("goxel.list_layers", [])
    ]
    
    for i, (method, params) in enumerate(methods, 1):
        request = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": i
        }
        
        print(f"\nRequest {i}: {method}")
        response = send_request(sock, request)
        print(f"Response {i}: {json.dumps(response, indent=2)}")
        
        assert response.get("id") == i, f"Wrong response ID"
        assert "error" not in response, f"Got error: {response.get('error')}"
    
    sock.close()
    print("\n✅ Mixed methods test passed!")
    return True

def test_rapid_fire():
    """Test rapid successive requests"""
    print("\n=== Test 3: Rapid Fire Requests ===")
    
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect("/tmp/goxel_test.sock")
    
    # Send 20 requests rapidly
    for i in range(1, 21):
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.add_voxels",
            "params": {
                "voxels": [{
                    "position": [i, i, i],
                    "color": [255, 0, 0, 255]
                }]
            },
            "id": i
        }
        
        response = send_request(sock, request)
        assert response.get("id") == i, f"Wrong response ID"
        
    sock.close()
    print("\n✅ Rapid fire test passed! (20 requests)")
    return True

def test_idle_connection():
    """Test connection survives idle periods"""
    print("\n=== Test 4: Idle Connection ===")
    
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect("/tmp/goxel_test.sock")
    
    # First request
    request1 = {
        "jsonrpc": "2.0",
        "method": "goxel.create_project",
        "params": ["IdleTest", 16, 16, 16],
        "id": 1
    }
    
    print("Sending initial request...")
    response1 = send_request(sock, request1)
    print(f"Response: {response1}")
    
    # Wait 2 seconds
    print("Waiting 2 seconds...")
    time.sleep(2)
    
    # Second request after idle
    request2 = {
        "jsonrpc": "2.0",
        "method": "goxel.list_layers",
        "params": [],
        "id": 2
    }
    
    print("Sending request after idle...")
    response2 = send_request(sock, request2)
    print(f"Response: {response2}")
    
    assert response2.get("id") == 2, "Wrong response ID after idle"
    
    sock.close()
    print("\n✅ Idle connection test passed!")
    return True

def test_concurrent_connections():
    """Test multiple concurrent connections"""
    print("\n=== Test 5: Concurrent Connections ===")
    
    def client_thread(client_id, results):
        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.connect("/tmp/goxel_test.sock")
            
            # Each client sends 3 requests
            for i in range(3):
                request = {
                    "jsonrpc": "2.0",
                    "method": "goxel.create_layer",
                    "params": [f"Client{client_id}_Layer{i}"],
                    "id": client_id * 100 + i
                }
                
                response = send_request(sock, request)
                assert response.get("id") == client_id * 100 + i
                
            sock.close()
            results[client_id] = True
        except Exception as e:
            print(f"Client {client_id} error: {e}")
            results[client_id] = False
    
    # Start 5 concurrent clients
    threads = []
    results = {}
    
    for i in range(5):
        t = threading.Thread(target=client_thread, args=(i, results))
        threads.append(t)
        t.start()
    
    # Wait for all to complete
    for t in threads:
        t.join()
    
    # Check results
    assert all(results.values()), "Some clients failed"
    
    print("\n✅ Concurrent connections test passed! (5 clients)")
    return True

def main():
    """Run all tests"""
    print("Goxel Daemon Connection Reuse Test Suite")
    print("========================================")
    
    # Start daemon
    import subprocess
    import os
    
    # Kill any existing daemon
    os.system("killall goxel-daemon 2>/dev/null")
    time.sleep(0.5)
    
    # Start daemon
    print("\nStarting daemon...")
    daemon = subprocess.Popen(
        ["./goxel-daemon", "--foreground", "--socket", "/tmp/goxel_test.sock"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    
    # Wait for daemon to start
    time.sleep(1)
    
    try:
        # Run tests
        tests = [
            test_basic_reuse,
            test_mixed_methods,
            test_rapid_fire,
            test_idle_connection,
            test_concurrent_connections
        ]
        
        passed = 0
        for test in tests:
            try:
                if test():
                    passed += 1
            except Exception as e:
                print(f"\n❌ Test failed: {e}")
        
        print(f"\n\nSummary: {passed}/{len(tests)} tests passed")
        
        if passed == len(tests):
            print("\n🎉 All tests passed! Connection reuse is working!")
            return 0
        else:
            print("\n❌ Some tests failed")
            return 1
            
    finally:
        # Clean up
        daemon.terminate()
        daemon.wait()
        os.system("killall goxel-daemon 2>/dev/null")

if __name__ == "__main__":
    sys.exit(main())