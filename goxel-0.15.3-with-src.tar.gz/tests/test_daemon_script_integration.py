#!/usr/bin/env python3
"""
Integration tests for daemon script execution functionality.
Tests the goxel.execute_script JSON-RPC method.
"""

import socket
import json
import time
import subprocess
import os
import tempfile
import sys

# Test configuration
DAEMON_PATH = os.path.join(os.path.dirname(__file__), "..", "goxel-daemon")
SOCKET_PATH = "/tmp/test_goxel_script_integration.sock"

def start_daemon():
    """Start the goxel daemon for testing"""
    cmd = [DAEMON_PATH, "--foreground", "--socket", SOCKET_PATH]
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    time.sleep(2)  # Give daemon time to start
    return process

def stop_daemon(process):
    """Stop the daemon"""
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        # Force kill if terminate doesn't work
        process.kill()
        process.wait()
    # Clean up socket file
    if os.path.exists(SOCKET_PATH):
        os.remove(SOCKET_PATH)

def send_request(sock, request):
    """Send JSON-RPC request and get response"""
    sock.send(json.dumps(request).encode() + b"\n")
    response = b""
    while True:
        chunk = sock.recv(4096)
        response += chunk
        if b"\n" in chunk:
            break
    return json.loads(response.decode().strip())

def test_simple_arithmetic():
    """Test simple arithmetic expressions"""
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(SOCKET_PATH)
    
    # Test arithmetic
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.execute_script",
        "params": {"script": "2 + 2"},
        "id": 1
    }
    response = send_request(sock, request)
    assert response["result"]["success"] == True
    assert response["result"]["code"] == 0
    print("✓ Simple arithmetic test passed")
    
    sock.close()

def test_error_handling():
    """Test error detection and reporting"""
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(SOCKET_PATH)
    
    # Test thrown error
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.execute_script",
        "params": {"script": "throw new Error('test error')"},
        "id": 1
    }
    response = send_request(sock, request)
    assert response["result"]["success"] == False
    assert response["result"]["code"] == -1
    assert "failed" in response["result"]["message"].lower()
    print("✓ Error handling test passed")
    
    # Test syntax error
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.execute_script",
        "params": {"script": "invalid syntax here"},
        "id": 2
    }
    response = send_request(sock, request)
    assert response["result"]["success"] == False
    assert response["result"]["code"] == -1
    print("✓ Syntax error test passed")
    
    sock.close()

def test_goxel_api_access():
    """Test that scripts can access the goxel API"""
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(SOCKET_PATH)
    
    # First create a project
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.create_project",
        "params": ["TestProject", 32, 32, 32],
        "id": 1
    }
    response = send_request(sock, request)
    assert response["result"]["success"] == True
    
    # Test accessing goxel object - it returns the type as a string result
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.execute_script",
        "params": {"script": "typeof goxel === 'object' ? 1 : 0"},
        "id": 2
    }
    response = send_request(sock, request)
    if not response["result"]["success"]:
        print(f"Script execution failed: {response}")
    assert response["result"]["success"] == True
    assert response["result"]["code"] == 0
    print("✓ Goxel API access test passed")
    
    sock.close()

def test_script_from_file():
    """Test executing scripts from files"""
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(SOCKET_PATH)
    
    # Create a test script file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
        f.write("""
// Test script
var result = 10 * 5;
result;  // Return value
""")
        script_path = f.name
    
    try:
        # Execute script from file
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.execute_script",
            "params": {"path": script_path},
            "id": 1
        }
        response = send_request(sock, request)
        assert response["result"]["success"] == True
        assert response["result"]["code"] == 0
        print("✓ Script from file test passed")
    finally:
        os.unlink(script_path)
    
    sock.close()

def test_concurrent_script_execution():
    """Test multiple scripts executing concurrently"""
    import threading
    
    results = []
    
    def execute_script(script_id):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        
        request = {
            "jsonrpc": "2.0",
            "method": "goxel.execute_script",
            "params": {"script": f"var x = {script_id}; x * x"},
            "id": script_id
        }
        response = send_request(sock, request)
        results.append((script_id, response))
        sock.close()
    
    # Launch multiple threads
    threads = []
    for i in range(5):
        t = threading.Thread(target=execute_script, args=(i,))
        threads.append(t)
        t.start()
    
    # Wait for all to complete
    for t in threads:
        t.join()
    
    # Verify all succeeded
    assert len(results) == 5
    for script_id, response in results:
        assert response["result"]["success"] == True
        assert response["result"]["code"] == 0
    
    print("✓ Concurrent execution test passed")

def test_script_timeout():
    """Test script timeout handling"""
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(SOCKET_PATH)
    
    # Test with custom timeout (this script should complete quickly)
    request = {
        "jsonrpc": "2.0",
        "method": "goxel.execute_script",
        "params": {
            "script": "1 + 1",
            "timeout_ms": 5000
        },
        "id": 1
    }
    response = send_request(sock, request)
    assert response["result"]["success"] == True
    print("✓ Script timeout test passed")
    
    sock.close()

def main():
    """Run all integration tests"""
    print("Starting Goxel daemon script execution integration tests...")
    
    # Start daemon
    daemon_process = start_daemon()
    
    try:
        # Run tests
        test_simple_arithmetic()
        test_error_handling()
        test_goxel_api_access()
        test_script_from_file()
        test_concurrent_script_execution()
        test_script_timeout()
        
        print("\n✅ All script execution integration tests passed!")
        return 0
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
        
    finally:
        # Stop daemon
        stop_daemon(daemon_process)

if __name__ == "__main__":
    sys.exit(main())